"""Content helpers for sending Telegram message types and formatting stored code."""
from __future__ import annotations
import html
import logging
import json
from typing import Any
from telegram import Message, MessageEntity, LinkPreviewOptions

log = logging.getLogger(__name__)


def message_content(message: Message) -> dict[str, str]:
    """Convert an incoming Telegram message to a storable content record."""
    text = message.caption or message.text or ""
    kind = "text"
    file_id = ""
    unique = ""
    if message.photo:
        kind, file_id, unique = "photo", message.photo[-1].file_id, message.photo[-1].file_unique_id
    elif message.video:
        kind, file_id, unique = "video", message.video.file_id, message.video.file_unique_id
    elif message.document:
        kind, file_id, unique = "document", message.document.file_id, message.document.file_unique_id
    elif message.audio:
        kind, file_id, unique = "audio", message.audio.file_id, message.audio.file_unique_id
    elif message.voice:
        kind, file_id, unique = "voice", message.voice.file_id, message.voice.file_unique_id
    elif message.animation:
        kind, file_id, unique = "animation", message.animation.file_id, message.animation.file_unique_id
    elif message.sticker:
        kind, file_id, unique = "sticker", message.sticker.file_id, message.sticker.file_unique_id
        text = ""
    elif message.video_note:
        kind, file_id, unique = "video_note", message.video_note.file_id, message.video_note.file_unique_id
        text = ""
    elif message.contact:
        kind, text = "contact", f"{message.contact.first_name} {message.contact.phone_number}"
    elif message.location:
        kind, text = "location", f"{message.location.latitude},{message.location.longitude}"
    entities = message.caption_entities if (message.caption and message.caption_entities) else (message.entities or [])
    entity_rows = []
    for entity in entities:
        row = {"type": entity.type, "offset": entity.offset, "length": entity.length}
        for attr in ("url", "language", "custom_emoji_id"):
            value = getattr(entity, attr, None)
            if value is not None:
                row[attr] = value
        if entity.user is not None:
            row["user"] = {"id": entity.user.id, "is_bot": entity.user.is_bot, "first_name": entity.user.first_name, "username": entity.user.username}
        entity_rows.append(row)
    return {"content_type": kind, "text_value": text, "file_id": file_id, "file_unique_id": unique, "entities_json": json.dumps(entity_rows, ensure_ascii=False)}


def _entities(item: Any, bot) -> list[MessageEntity]:
    raw = item["entities_json"] if "entities_json" in item.keys() else "[]"
    try:
        records = json.loads(raw or "[]")
    except (TypeError, json.JSONDecodeError):
        records = []
    result = []
    for record in records if isinstance(records, list) else []:
        try:
            result.append(MessageEntity.de_json(record, bot))
        except Exception:
            continue
    return result


async def send_content(bot, chat_id: int, item: Any, settings: dict | None = None):
    """Send a stored content row. Returns Telegram's Message or list of Messages."""
    settings = settings or {}
    kind = str(item["content_type"])
    text = str(item["text_value"] or "")
    file_id = str(item["file_id"] or "")
    protect = bool(settings.get("protect", False))
    silent = bool(settings.get("silent", False))
    common = {"chat_id": chat_id, "disable_notification": silent, "protect_content": protect}
    if kind == "text":
        if not text:
            return None
        preview = settings.get("link_preview", True)
        entities = _entities(item, bot)
        return await bot.send_message(**common, text=text, entities=entities or None, link_preview_options=LinkPreviewOptions(is_disabled=not preview))
    if kind == "photo":
        return await bot.send_photo(**common, photo=file_id, caption=text or None, caption_entities=_entities(item, bot) or None, has_spoiler=bool(settings.get("spoiler", False)))
    if kind == "video":
        return await bot.send_video(**common, video=file_id, caption=text or None, caption_entities=_entities(item, bot) or None, has_spoiler=bool(settings.get("spoiler", False)))
    if kind == "document":
        return await bot.send_document(**common, document=file_id, caption=text or None, caption_entities=_entities(item, bot) or None)
    if kind == "audio":
        return await bot.send_audio(**common, audio=file_id, caption=text or None, caption_entities=_entities(item, bot) or None)
    if kind == "voice":
        return await bot.send_voice(**common, voice=file_id, caption=text or None, caption_entities=_entities(item, bot) or None)
    if kind == "animation":
        return await bot.send_animation(**common, animation=file_id, caption=text or None, caption_entities=_entities(item, bot) or None, has_spoiler=bool(settings.get("spoiler", False)))
    if kind == "sticker":
        return await bot.send_sticker(**common, sticker=file_id)
    if kind == "video_note":
        return await bot.send_video_note(**common, video_note=file_id)
    if kind == "contact":
        try:
            first, phone = text.split(" ", 1)
        except ValueError:
            first, phone = "Contact", text
        return await bot.send_contact(**common, phone_number=phone, first_name=first)
    if kind == "location":
        lat, lon = text.split(",", 1)
        return await bot.send_location(**common, latitude=float(lat), longitude=float(lon))
    log.warning("Unknown content type: %s", kind)
    return None


def safe_code_html(source: str) -> str:
    """Escape code before wrapping it in HTML; never executes user code."""
    return "<pre><code class=\"language-python\">" + html.escape(source[:3500]) + "</code></pre>"


def content_summary(item: Any) -> str:
    kind = str(item["content_type"])
    text = str(item["text_value"] or "")
    names = {"text": "نص", "photo": "صورة", "video": "فيديو", "document": "ملف", "audio": "صوت", "voice": "رسالة صوتية", "animation": "GIF", "sticker": "ملصق", "video_note": "فيديو دائري", "contact": "جهة اتصال", "location": "موقع"}
    snippet = " ".join(text.split())[:55]
    return f"{names.get(kind, kind)}" + (f": {snippet}" if snippet else "")
