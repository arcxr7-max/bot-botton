"""Portable .mkfrky backup helpers with optional authenticated encryption."""
from __future__ import annotations
import json
import os
import zipfile
from pathlib import Path
from typing import Any
import base64

try:
    from cryptography.fernet import Fernet, InvalidToken
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
except ImportError:  # Optional on Android/Pydroid environments without a compatible wheel.
    Fernet = None
    InvalidToken = Exception
    hashes = None
    PBKDF2HMAC = None

MAGIC = b"ARCEN-MKFRKY-1\n"


def _require_crypto() -> None:
    if Fernet is None or hashes is None or PBKDF2HMAC is None:
        raise RuntimeError(
            "التشفير يحتاج إلى مكتبة cryptography؛ النسخ الاحتياطي غير المشفر متاح عند ترك كلمة المرور فارغة."
        )


def _derive_key(password: str, salt: bytes) -> bytes:
    _require_crypto()
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=390_000)
    return base64.urlsafe_b64encode(kdf.derive(password.encode("utf-8")))


def create_backup(snapshot: dict[str, Any], destination: str | Path, password: str = "") -> Path:
    """Create a compressed backup; password mode encrypts the whole archive."""
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(snapshot, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if password:
        salt = os.urandom(16)
        encrypted = Fernet(_derive_key(password, salt)).encrypt(raw)
        payload = MAGIC + b"E" + salt + encrypted
    else:
        payload = MAGIC + b"P" + raw
    destination.write_bytes(payload)
    return destination


def read_backup(source: str | Path, password: str = "") -> dict[str, Any]:
    payload = Path(source).read_bytes()
    if not payload.startswith(MAGIC) or len(payload) <= len(MAGIC):
        raise ValueError("هذا الملف ليس نسخة ARCEN MKFRKY معروفة")
    mode = payload[len(MAGIC):len(MAGIC)+1]
    body = payload[len(MAGIC)+1:]
    if mode == b"E":
        _require_crypto()
        if not password:
            raise ValueError("هذه النسخة مشفرة، أدخل كلمة المرور")
        if len(body) < 17:
            raise ValueError("ملف النسخة المشفرة تالف")
        salt, encrypted = body[:16], body[16:]
        try:
            raw = Fernet(_derive_key(password, salt)).decrypt(encrypted)
        except InvalidToken as exc:
            raise ValueError("كلمة المرور غير صحيحة أو الملف تالف") from exc
    elif mode == b"P":
        raw = body
    else:
        raise ValueError("إصدار أو نمط نسخة غير معروف")
    try:
        result = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("محتوى النسخة الاحتياطية غير صالح") from exc
    if not isinstance(result, dict) or result.get("format") != "ARCEN-MKFRKY":
        raise ValueError("بنية النسخة الاحتياطية غير صالحة")
    return result
