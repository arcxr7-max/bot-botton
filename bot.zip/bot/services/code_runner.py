
"""Restricted runner for trusted-admin Python snippets."""
import os
import subprocess
import sys

MAX_CODE_CHARS = 12000
MAX_OUTPUT_CHARS = 3500
TIMEOUT_SECONDS = 5

_RUNNER = r'''
import ast
import sys
import math, random, json, re, statistics
import decimal, fractions, itertools, collections, datetime
import builtins

code = sys.stdin.read()

allowed_imports = {
    "math", "random", "json", "re", "statistics", "decimal",
    "fractions", "itertools", "collections", "datetime"
}
blocked_names = {
    "open", "eval", "exec", "compile", "__import__", "input",
    "breakpoint", "globals", "locals", "vars", "help", "dir"
}

try:
    tree = ast.parse(code, mode="exec")

    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            if isinstance(node, ast.Import):
                names = [a.name.split(".")[0] for a in node.names]
            else:
                names = [(node.module or "").split(".")[0]]

            if any(name not in allowed_imports for name in names):
                raise ValueError("هذا الاستيراد غير مسموح.")

        if isinstance(node, ast.Name):
            if node.id in blocked_names or node.id.startswith("__"):
                raise ValueError("استخدم الكود وظيفة غير مسموحة.")

        if isinstance(node, ast.Attribute) and node.attr.startswith("__"):
            raise ValueError("الوصول إلى الخصائص الداخلية غير مسموح.")

    safe_names = (
        "abs all any bool dict enumerate filter float format int len "
        "list map max min range reversed round set slice sorted str "
        "sum tuple type zip print Exception ValueError TypeError "
        "KeyError IndexError ZeroDivisionError"
    ).split()

    safe_builtins = {
        name: getattr(builtins, name) for name in safe_names
    }

    scope = {
        "__builtins__": safe_builtins,
        "math": math, "random": random, "json": json, "re": re,
        "statistics": statistics, "decimal": decimal,
        "fractions": fractions, "itertools": itertools,
        "collections": collections, "datetime": datetime
    }

    exec(compile(tree, "<arcen-code>", "exec"), scope, scope)

except BaseException as exc:
    print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
    sys.exit(1)
'''


def run_python(code: str) -> tuple[bool, str]:
    """Return (success, output) for a Python snippet."""
    code = str(code or "")

    if not code.strip():
        return False, "الكود فارغ."

    if len(code) > MAX_CODE_CHARS:
        return False, f"حجم الكود أكبر من الحد المسموح ({MAX_CODE_CHARS} حرف)."

    try:
        result = subprocess.run(
            [sys.executable, "-I", "-c", _RUNNER],
            input=code,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=TIMEOUT_SECONDS,
            env=os.environ.copy(),
        )
    except subprocess.TimeoutExpired:
        return False, f"انتهى وقت التنفيذ؛ الحد الأقصى {TIMEOUT_SECONDS} ثوانٍ."
    except Exception as exc:
        return False, f"تعذر تشغيل Python: {type(exc).__name__}: {exc}"

    output = (result.stdout or "").strip()
    error = (result.stderr or "").strip()

    if result.returncode != 0:
        return False, (error or output or "فشل تنفيذ الكود.")[:MAX_OUTPUT_CHARS]

    return True, (
        output or "انتهى التنفيذ بنجاح، لكن الكود لم يطبع مخرجات."
    )[:MAX_OUTPUT_CHARS]
