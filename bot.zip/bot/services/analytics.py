"""Admin analytics and UTF-8 CSV export."""
from __future__ import annotations
import csv
import io
from datetime import datetime, timedelta, timezone
from typing import Any


def overall_stats(db) -> dict[str, int]:
    queries = {
        "users": "SELECT COUNT(*) n FROM users",
        "active_users_7d": "SELECT COUNT(*) n FROM users WHERE last_seen>=?",
        "blocked_users": "SELECT COUNT(*) n FROM users WHERE is_blocked=1",
        "buttons": "SELECT COUNT(*) n FROM buttons",
        "enabled_buttons": "SELECT COUNT(*) n FROM buttons WHERE enabled=1",
        "contents": "SELECT COUNT(*) n FROM button_contents",
        "folders": "SELECT COUNT(*) n FROM folders",
        "templates": "SELECT COUNT(*) n FROM templates",
        "button_uses": "SELECT COUNT(*) n FROM button_usage",
        "surveys": "SELECT COUNT(*) n FROM surveys",
        "completed_surveys": "SELECT COUNT(*) n FROM survey_responses WHERE completed=1",
    }
    cutoff = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat(timespec="seconds")
    result: dict[str, int] = {}
    for key, sql in queries.items():
        row = db.fetchone(sql, (cutoff,)) if "?" in sql else db.fetchone(sql)
        result[key] = int(row["n"] if row else 0)
    return result


def button_stats(db, button_id: int) -> dict[str, Any]:
    row = db.fetchone("SELECT id,name,kind,enabled,created_at FROM buttons WHERE id=?", (button_id,))
    if not row:
        raise ValueError("الزر غير موجود")
    uses = db.fetchone("SELECT COUNT(*) n FROM button_usage WHERE button_id=?", (button_id,))["n"]
    people = db.fetchone("SELECT COUNT(DISTINCT user_id) n FROM button_usage WHERE button_id=?", (button_id,))["n"]
    contents = db.fetchone("SELECT COUNT(*) n FROM button_contents WHERE button_id=?", (button_id,))["n"]
    cutoff = (datetime.now(timezone.utc)-timedelta(days=7)).isoformat(timespec="seconds")
    recent = db.fetchone("SELECT COUNT(*) n FROM button_usage WHERE button_id=? AND used_at>=?", (button_id, cutoff))["n"]
    return {"button": dict(row), "uses": int(uses), "unique_users": int(people), "contents": int(contents), "uses_7d": int(recent)}


def export_survey_csv(db, survey_id: int) -> bytes:
    survey = db.fetchone("SELECT id FROM surveys WHERE id=?", (survey_id,))
    if not survey:
        raise ValueError("الاستبيان غير موجود")
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(["response_id", "user_id", "completed", "score", "started_at", "completed_at", "question_id", "question", "answer", "is_correct"])
    responses = db.fetchall("SELECT * FROM survey_responses WHERE survey_id=? ORDER BY id", (survey_id,))
    for response in responses:
        answers = db.fetchall("""SELECT sa.question_id,sq.question,sa.answer_text,sa.is_correct
            FROM survey_answers sa JOIN survey_questions sq ON sq.id=sa.question_id
            WHERE sa.response_id=? ORDER BY sq.position""", (response["id"],))
        if not answers:
            writer.writerow([response["id"], response["user_id"], response["completed"], response["score"], response["started_at"], response["completed_at"], "", "", "", ""])
        for answer in answers:
            writer.writerow([response["id"], response["user_id"], response["completed"], response["score"], response["started_at"], response["completed_at"], answer["question_id"], answer["question"], answer["answer_text"], answer["is_correct"]])
    return ("\ufeff" + output.getvalue()).encode("utf-8")


def survey_summary(db, survey_id: int) -> dict[str, Any]:
    survey = db.fetchone("SELECT * FROM surveys WHERE id=?", (survey_id,))
    if not survey:
        raise ValueError("الاستبيان غير موجود")
    started = db.fetchone("SELECT COUNT(*) n FROM survey_responses WHERE survey_id=?", (survey_id,))["n"]
    completed = db.fetchone("SELECT COUNT(*) n FROM survey_responses WHERE survey_id=? AND completed=1", (survey_id,))["n"]
    questions = db.fetchall("SELECT id,position,question_type,question FROM survey_questions WHERE survey_id=? ORDER BY position", (survey_id,))
    distributions = []
    for question in questions:
        answers = db.fetchall("SELECT answer_text,COUNT(*) n FROM survey_answers WHERE question_id=? GROUP BY answer_text ORDER BY n DESC LIMIT 25", (question["id"],))
        distributions.append({"question": question["question"], "answers": [(a["answer_text"], int(a["n"])) for a in answers]})
    return {"started": int(started), "completed": int(completed), "questions": distributions, "survey": dict(survey)}


def top_buttons(db, limit: int = 10) -> list[dict[str, Any]]:
    limit = max(1, min(int(limit), 50))
    return [dict(row) for row in db.fetchall("""SELECT b.id,b.name,b.kind,COUNT(u.id) uses,COUNT(DISTINCT u.user_id) people
      FROM buttons b LEFT JOIN button_usage u ON u.button_id=b.id GROUP BY b.id ORDER BY uses DESC,b.id DESC LIMIT ?""", (limit,))]
