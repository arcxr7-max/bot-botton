"""Survey question parsing, keyboard rendering, and answer validation."""
from __future__ import annotations
import json
from typing import Any
from telegram import InlineKeyboardButton, InlineKeyboardMarkup


def decode_options(question: dict[str, Any]) -> list[str]:
    if question.get("question_type") == "rating":
        return [str(number) for number in range(1, 6)]
    try:
        options = json.loads(question.get("options_json") or "[]")
    except (TypeError, json.JSONDecodeError):
        return []
    return [str(item)[:100] for item in options[:20]] if isinstance(options, list) else []


def question_markup(question: dict[str, Any], response_id: int, question_index: int) -> InlineKeyboardMarkup | None:
    if question.get("question_type") not in {"choice", "rating"}:
        return None
    options = decode_options(question)
    rows = [[InlineKeyboardButton(("⭐ " if question.get("question_type") == "rating" else "") + option, callback_data=f"survey_pick:{response_id}:{question_index}:{idx}")]
            for idx, option in enumerate(options)]
    return InlineKeyboardMarkup(rows) if rows else None


def validate_answer(question: dict[str, Any], answer: str) -> tuple[bool, str]:
    kind = str(question.get("question_type") or "text")
    value = (answer or "").strip()
    if kind == "number":
        try:
            float(value)
        except ValueError:
            return False, "هذا السؤال يتطلب رقمًا. حاول مرة أخرى."
    elif kind == "rating":
        try:
            score = int(value)
        except ValueError:
            return False, "أرسل تقييمًا من 1 إلى 5."
        if score < 1 or score > 5:
            return False, "التقييم يجب أن يكون من 1 إلى 5."
    elif kind == "choice":
        return False, "اختر إجابة من الأزرار الظاهرة أسفل السؤال."
    return True, value[:2000]


def answer_is_correct(question: dict[str, Any], selected_index: int) -> bool | None:
    if question.get("correct_option") is None:
        return None
    try:
        return int(question["correct_option"]) == int(selected_index)
    except (TypeError, ValueError):
        return None
