"""Safe formatting helpers. User code is escaped, never evaluated."""
from __future__ import annotations
import html
import re
from typing import Iterable


def escape_html(value: object) -> str:
    return html.escape(str(value or ""), quote=True)


def code_block(source: str, language: str = "python", limit: int = 3500) -> str:
    language = re.sub(r"[^a-zA-Z0-9_+-]", "", language)[:20] or "text"
    return f'<pre><code class="language-{language}">{escape_html(source[:limit])}</code></pre>'


def truncate(value: object, limit: int = 100, suffix: str = "…") -> str:
    text = str(value or "")
    return text if len(text) <= limit else text[:max(0, limit-len(suffix))] + suffix


def bullet_list(values: Iterable[object], empty: str = "لا توجد عناصر.", limit: int = 30) -> str:
    lines = [f"• {truncate(value, 160)}" for value in list(values)[:limit]]
    return "\n".join(lines) if lines else empty


def human_bytes(value: int) -> str:
    size = float(max(0, value))
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} GB"


def normalize_keyword(value: str) -> str:
    return " ".join((value or "").casefold().split())


def parse_key_value_lines(value: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for line in (value or "").splitlines():
        if "=" not in line:
            continue
        key, val = line.split("=", 1)
        key = key.strip()
        if key:
            result[key[:80]] = val.strip()[:1000]
    return result
