"""Scheduling and availability checks for time-limited buttons."""
from __future__ import annotations
from datetime import datetime, timezone
from typing import Any


def parse_iso_datetime(value: str) -> datetime | None:
    try:
        parsed = datetime.fromisoformat(value)
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def is_available(settings: dict[str, Any], now: datetime | None = None) -> tuple[bool, str]:
    now = now or datetime.now(timezone.utc)
    start = settings.get("schedule")
    end = settings.get("schedule_end")
    if start:
        parsed = parse_iso_datetime(str(start))
        if parsed and now < parsed:
            return False, "هذا الزر لم يصبح متاحًا بعد."
    if end:
        parsed = parse_iso_datetime(str(end))
        if parsed and now > parsed:
            return False, "انتهت مدة إتاحة هذا الزر."
    return True, ""


def seconds_until(value: str, now: datetime | None = None) -> int | None:
    parsed = parse_iso_datetime(value)
    if parsed is None:
        return None
    now = now or datetime.now(timezone.utc)
    return max(0, int((parsed - now).total_seconds()))


def validate_job_payload(payload: dict[str, Any]) -> tuple[bool, str]:
    if not isinstance(payload, dict):
        return False, "بيانات المهمة غير صالحة."
    if not isinstance(payload.get("button_id"), int):
        return False, "معرّف الزر غير صالح."
    if payload.get("action") not in {"enable", "disable", "broadcast_content"}:
        return False, "نوع المهمة غير مدعوم."
    return True, "ok"
