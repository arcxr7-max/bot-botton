"""Forced-subscription checks using Telegram membership information."""
from __future__ import annotations
from telegram import InlineKeyboardButton, InlineKeyboardMarkup


def active_subscriptions(db):
    return db.fetchall("SELECT * FROM subscriptions WHERE enabled=1 ORDER BY id")


async def check_membership(bot, user_id: int, db) -> tuple[bool, list[dict]]:
    missing = []
    for row in active_subscriptions(db):
        try:
            member = await bot.get_chat_member(chat_id=row["chat_id"], user_id=user_id)
            status = getattr(member, "status", "left")
            is_member = status in {"member", "administrator", "creator"}
            if status == "restricted":
                is_member = bool(getattr(member, "is_member", False))
            if not is_member:
                missing.append(dict(row))
        except Exception:
            missing.append(dict(row))
    return not missing, missing


def subscription_keyboard(rows: list[dict]) -> InlineKeyboardMarkup:
    buttons = []
    for row in rows:
        chat_value = str(row.get("chat_id", ""))
        public_url = f"https://t.me/{chat_value[1:]}" if chat_value.startswith("@") else ""
        url = row.get("invite_url") or public_url or (chat_value if chat_value.startswith("https://") else "")
        if url:
            buttons.append([InlineKeyboardButton(f"📢 اشترك في {row.get('title') or 'القناة'}", url=url)])
    buttons.append([InlineKeyboardButton("✅ تحقّق من الاشتراك", callback_data="subscription:check")])
    return InlineKeyboardMarkup(buttons)
