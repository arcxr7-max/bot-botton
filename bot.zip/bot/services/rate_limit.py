"""Small in-memory rate limiter for chat actions and expensive admin flows."""
from __future__ import annotations
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass

@dataclass(frozen=True)
class RateLimitResult:
    allowed: bool
    retry_after: float = 0.0
    reason: str = ""

class SlidingWindowLimiter:
    """Thread-safe sliding-window limiter. State resets when the process restarts."""
    def __init__(self, max_events: int = 8, window_seconds: float = 10.0):
        self.max_events = max(1, int(max_events))
        self.window_seconds = max(0.1, float(window_seconds))
        self._events: dict[tuple[int, str], deque[float]] = defaultdict(deque)
        self._lock = threading.Lock()

    def check(self, user_id: int, scope: str = "default", now: float | None = None) -> RateLimitResult:
        timestamp = time.monotonic() if now is None else float(now)
        key = (int(user_id), str(scope))
        with self._lock:
            events = self._events[key]
            cutoff = timestamp - self.window_seconds
            while events and events[0] <= cutoff:
                events.popleft()
            if len(events) >= self.max_events:
                retry = max(0.05, self.window_seconds - (timestamp - events[0]))
                return RateLimitResult(False, retry, "rate limit exceeded")
            events.append(timestamp)
            self._cleanup(timestamp)
            return RateLimitResult(True)

    def _cleanup(self, now: float) -> None:
        if len(self._events) < 2048:
            return
        cutoff = now - self.window_seconds * 2
        for key in list(self._events.keys()):
            events = self._events[key]
            while events and events[0] < cutoff:
                events.popleft()
            if not events:
                self._events.pop(key, None)

    def reset(self, user_id: int, scope: str | None = None) -> None:
        with self._lock:
            if scope is None:
                for key in [key for key in self._events if key[0] == int(user_id)]:
                    self._events.pop(key, None)
            else:
                self._events.pop((int(user_id), str(scope)), None)

    def inspect(self) -> dict[str, int]:
        with self._lock:
            return {"tracked_keys": len(self._events), "tracked_events": sum(len(q) for q in self._events.values())}


def clamp_page(value: int, page_size: int, total: int) -> tuple[int, int]:
    page_size = max(1, min(int(page_size), 100))
    total = max(0, int(total))
    max_page = max(0, (total - 1) // page_size)
    page = max(0, min(int(value), max_page))
    return page, max_page


def paginate(items: list, page: int = 0, page_size: int = 10) -> tuple[list, int, int]:
    page, max_page = clamp_page(page, page_size, len(items))
    start = page * page_size
    return items[start:start + page_size], page, max_page
