"""Validation and normalization helpers for all user-controlled input."""
from __future__ import annotations
import re
from urllib.parse import urlparse
from typing import Any

MAX_BUTTON_NAME = 64
MAX_TEXT = 4000
MAX_QUESTION = 500
MAX_OPTIONS = 20


def clean_text(value: Any, limit: int = MAX_TEXT) -> str:
    if value is None:
        return ""
    return str(value).replace("\x00", "")[:max(0, int(limit))]


def clean_single_line(value: Any, limit: int = MAX_BUTTON_NAME) -> str:
    return " ".join(clean_text(value, limit * 3).split())[:limit]


def validate_button_name(value: Any) -> tuple[bool, str]:
    name = clean_single_line(value, MAX_BUTTON_NAME)
    if not name:
        return False, "اسم الزر مطلوب."
    if name.startswith("/"):
        return False, "لا تستخدم اسم أمر يبدأ بشرطة مائلة."
    return True, name


def validate_https_url(value: Any) -> tuple[bool, str]:
    raw = clean_single_line(value, 2048)
    parsed = urlparse(raw)
    if parsed.scheme != "https" or not parsed.netloc or any(ch.isspace() for ch in raw):
        return False, "أرسل رابط HTTPS صالحًا دون مسافات."
    return True, raw


def validate_integer(value: Any, minimum: int = 0, maximum: int = 1_000_000) -> tuple[bool, int | str]:
    try:
        number = int(str(value).strip())
    except (TypeError, ValueError):
        return False, "أرسل رقمًا صحيحًا."
    if not minimum <= number <= maximum:
        return False, f"القيمة يجب أن تكون بين {minimum} و{maximum}."
    return True, number


def parse_survey_question(value: str) -> dict[str, Any]:
    """Syntax: اختياري: السؤال | خيار 1 | خيار 2, رقمي: السؤال, تقييم: السؤال."""
    raw = clean_text(value, MAX_QUESTION * 3).strip()
    kind, body = "text", raw
    prefixes = (("اختياري:", "choice"), ("choice:", "choice"), ("رقمي:", "number"),
                ("number:", "number"), ("تقييم:", "rating"), ("rating:", "rating"),
                ("نصي:", "text"), ("text:", "text"))
    for prefix, mapped in prefixes:
        if raw.lower().startswith(prefix.lower()):
            kind, body = mapped, raw[len(prefix):].strip()
            break
    if kind == "choice":
        parts = [part.strip() for part in body.split("|")]
        question = parts[0][:MAX_QUESTION] if parts else ""
        raw_options = [part.strip() for part in parts[1:] if part.strip()][:MAX_OPTIONS]
        correct_option = None
        options = []
        for option in raw_options:
            if option.startswith("*") and correct_option is None:
                correct_option = len(options)
                option = option[1:].strip()
            options.append(clean_single_line(option, 100))
        if not question or len(options) < 2:
            return {"ok": False, "error": "سؤال الاختيار يحتاج سؤالًا وخيارين على الأقل: اختياري: السؤال | خيار 1 | خيار 2"}
        return {"ok": True, "type": kind, "question": question, "options": options, "correct_option": correct_option}
    if not body:
        return {"ok": False, "error": "نص السؤال مطلوب."}
    return {"ok": True, "type": kind, "question": body[:MAX_QUESTION], "options": [], "correct_option": None}


def parse_chat_id(value: str) -> int | str | None:
    value = (value or "").strip()
    if value.startswith("@") and len(value) > 1:
        return value
    try:
        return int(value)
    except ValueError:
        return None


def safe_callback_value(value: Any, limit: int = 48) -> str:
    return re.sub(r"[^A-Za-z0-9_-]", "", str(value))[:limit]


def validate_kind(kind: str) -> bool:
    return kind in {"content", "folder", "multi", "random", "info", "search", "webapp", "daily", "template", "survey", "code", "mirror"}
