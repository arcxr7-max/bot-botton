"""User-management queries and safe admin actions."""
from __future__ import annotations
from typing import Any
from database import utc_now


def search_users(db, term: str, limit: int = 25) -> list[dict[str, Any]]:
    term = (term or "").strip()[:100]
    if not term:
        return []
    limit = max(1, min(int(limit), 100))
    if term.isdigit():
        rows = db.fetchall("SELECT * FROM users WHERE user_id=? OR username LIKE ? ORDER BY last_seen DESC LIMIT ?", (int(term), f"%{term}%", limit))
    else:
        rows = db.fetchall("SELECT * FROM users WHERE username LIKE ? COLLATE NOCASE OR first_name LIKE ? COLLATE NOCASE ORDER BY last_seen DESC LIMIT ?", (f"%{term}%", f"%{term}%", limit))
    return [dict(row) for row in rows]


def user_detail(db, user_id: int) -> dict[str, Any] | None:
    user = db.fetchone("SELECT * FROM users WHERE user_id=?", (int(user_id),))
    if not user:
        return None
    counts = db.fetchone("SELECT COUNT(*) n FROM button_usage WHERE user_id=?", (int(user_id),))
    return {**dict(user), "button_uses": int(counts["n"] if counts else 0)}


def set_blocked(db, user_id: int, blocked: bool, actor_id: int) -> bool:
    row = db.fetchone("SELECT user_id FROM users WHERE user_id=?", (int(user_id),))
    if not row:
        return False
    db.execute("UPDATE users SET is_blocked=? WHERE user_id=?", (int(bool(blocked)), int(user_id)))
    db.log(int(actor_id), "user_blocked" if blocked else "user_unblocked", str(int(user_id)))
    return True


def list_users_page(db, page: int = 0, page_size: int = 20, include_blocked: bool = False) -> tuple[list[dict[str, Any]], int]:
    page_size = max(1, min(int(page_size), 100))
    where = "" if include_blocked else "WHERE is_blocked=0"
    total = int(db.fetchone(f"SELECT COUNT(*) n FROM users {where}")["n"])
    max_page = max(0, (total - 1) // page_size)
    page = max(0, min(int(page), max_page))
    rows = db.fetchall(f"SELECT user_id,username,first_name,joined_at,last_seen,is_blocked,points FROM users {where} ORDER BY last_seen DESC LIMIT ? OFFSET ?", (page_size, page * page_size))
    return [dict(row) for row in rows], max_page


def points_history(db, user_id: int, limit: int = 50) -> list[dict[str, Any]]:
    limit = max(1, min(int(limit), 200))
    return [dict(row) for row in db.fetchall("SELECT * FROM points_log WHERE user_id=? ORDER BY id DESC LIMIT ?", (int(user_id), limit))]
