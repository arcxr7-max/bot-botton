"""Unit tests for non-Telegram service utilities."""
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from database import Database, utc_now
from services.validation import validate_button_name, validate_https_url, validate_integer, parse_survey_question
from services.scheduler import is_available, parse_iso_datetime, seconds_until
from services.rate_limit import SlidingWindowLimiter, paginate
from services.analytics import overall_stats, button_stats, export_survey_csv

class ValidationTests(unittest.TestCase):
    def test_button_name_rejects_blank_and_commands(self):
        self.assertFalse(validate_button_name("   ")[0])
        self.assertFalse(validate_button_name("/start")[0])
        self.assertEqual(validate_button_name("  زر   تجريبي  ")[1], "زر تجريبي")

    def test_https_validation(self):
        self.assertTrue(validate_https_url("https://example.com/path")[0])
        self.assertFalse(validate_https_url("http://example.com")[0])
        self.assertFalse(validate_https_url("not-a-url")[0])

    def test_integer_bounds(self):
        self.assertEqual(validate_integer("12", 0, 20), (True, 12))
        self.assertFalse(validate_integer("-1", 0, 20)[0])
        self.assertFalse(validate_integer("abc", 0, 20)[0])

    def test_survey_choice_syntax(self):
        parsed = parse_survey_question("اختياري: اختر | خطأ | *صحيح | ربما")
        self.assertTrue(parsed["ok"])
        self.assertEqual(parsed["type"], "choice")
        self.assertEqual(parsed["correct_option"], 1)
        self.assertEqual(len(parsed["options"]), 3)

    def test_survey_choice_requires_two_options(self):
        self.assertFalse(parse_survey_question("اختياري: سؤال | خيار واحد")["ok"])

class SchedulerTests(unittest.TestCase):
    def test_iso_datetime(self):
        self.assertIsNotNone(parse_iso_datetime("2026-10-20T12:00:00"))
        self.assertIsNone(parse_iso_datetime("not-a-date"))

    def test_availability_start_and_end(self):
        now = datetime(2026, 10, 19, tzinfo=timezone.utc)
        ok, _ = is_available({"schedule": "2026-10-20T00:00:00+00:00"}, now)
        self.assertFalse(ok)
        ok, _ = is_available({"schedule_end": "2026-10-18T00:00:00+00:00"}, now)
        self.assertFalse(ok)
        self.assertTrue(is_available({}, now)[0])

    def test_seconds_until(self):
        now = datetime(2026, 1, 1, tzinfo=timezone.utc)
        self.assertEqual(seconds_until("2026-01-01T00:00:10+00:00", now), 10)
        self.assertEqual(seconds_until("2025-01-01T00:00:00+00:00", now), 0)

class RateLimitTests(unittest.TestCase):
    def test_sliding_window(self):
        limiter = SlidingWindowLimiter(max_events=2, window_seconds=5)
        self.assertTrue(limiter.check(1, now=10).allowed)
        self.assertTrue(limiter.check(1, now=11).allowed)
        result = limiter.check(1, now=12)
        self.assertFalse(result.allowed)
        self.assertGreater(result.retry_after, 0)
        self.assertTrue(limiter.check(1, now=16).allowed)

    def test_pagination(self):
        page, current, max_page = paginate(list(range(25)), 2, 10)
        self.assertEqual(page, [20, 21, 22, 23, 24])
        self.assertEqual((current, max_page), (2, 2))

class AnalyticsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tmp.name) / "analytics.sqlite3")
        self.db.upsert_user(101, "alpha", "Alpha")
        self.bid = self.db.execute("INSERT INTO buttons(name,kind,created_by,created_at,updated_at) VALUES(?,?,?,?,?)", ("Stats", "content", 101, utc_now(), utc_now()))
        self.db.add_content(self.bid, "text", "hello")
        self.db.execute("INSERT INTO button_usage(button_id,user_id,used_at) VALUES(?,?,?)", (self.bid, 101, utc_now()))

    def tearDown(self):
        self.tmp.cleanup()

    def test_overall_stats(self):
        stats = overall_stats(self.db)
        self.assertEqual(stats["users"], 1)
        self.assertEqual(stats["buttons"], 1)
        self.assertEqual(stats["button_uses"], 1)

    def test_button_stats(self):
        stats = button_stats(self.db, self.bid)
        self.assertEqual(stats["uses"], 1)
        self.assertEqual(stats["unique_users"], 1)
        self.assertEqual(stats["contents"], 1)

    def test_export_requires_existing_survey(self):
        with self.assertRaises(ValueError):
            export_survey_csv(self.db, 999)

if __name__ == "__main__":
    unittest.main()
