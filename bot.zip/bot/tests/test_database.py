"""Small local smoke tests for database and backup behavior."""
import json
import tempfile
import unittest
from pathlib import Path
from database import Database, utc_now
from services.backup import create_backup, read_backup

class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tmp.name) / "test.sqlite3")

    def tearDown(self):
        self.tmp.cleanup()

    def test_create_button_and_content(self):
        bid = self.db.execute("INSERT INTO buttons(name,kind,created_by,created_at,updated_at) VALUES(?,?,?,?,?)", ("Demo", "content", 1, utc_now(), utc_now()))
        self.db.add_content(bid, "text", "hello")
        self.assertEqual(self.db.get_button(bid)["name"], "Demo")
        self.assertEqual(self.db.get_contents(bid)[0]["text_value"], "hello")

    def test_settings_roundtrip(self):
        bid = self.db.execute("INSERT INTO buttons(name,kind,created_by,created_at,updated_at) VALUES(?,?,?,?,?)", ("Demo", "content", 1, utc_now(), utc_now()))
        self.db.set_settings(bid, {"protect": True, "cooldown": 4})
        self.assertEqual(self.db.get_settings(bid)["cooldown"], 4)

    def test_backup_roundtrip(self):
        self.db.upsert_user(10, "tester", "Tester")
        snapshot = self.db.export_snapshot()
        path = Path(self.tmp.name) / "test.mkfrky"
        create_backup(snapshot, path, "pass123")
        self.assertEqual(read_backup(path, "pass123")["format"], "ARCEN-MKFRKY")
        with self.assertRaises(ValueError):
            read_backup(path, "wrong")

if __name__ == "__main__":
    unittest.main()
