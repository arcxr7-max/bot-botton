import unittest
from services.code_runner import run_python

class CodeRunnerTests(unittest.TestCase):
    def test_captures_print_output(self):
        ok, output = run_python('message = "Hello from ARCEN!"\nprint(message)\nprint("تم تشغيل الكود بنجاح!")')
        self.assertTrue(ok)
        self.assertIn('Hello from ARCEN!', output)
        self.assertIn('تم تشغيل الكود بنجاح!', output)

    def test_reports_runtime_errors(self):
        ok, output = run_python('print(1 / 0)')
        self.assertFalse(ok)
        self.assertIn('ZeroDivisionError', output)

    def test_blocks_disallowed_imports(self):
        ok, output = run_python('import os\nprint(os.getcwd())')
        self.assertFalse(ok)
        self.assertIn('غير مسموح', output)

    def test_empty_code(self):
        ok, output = run_python('  ')
        self.assertFalse(ok)
        self.assertIn('فارغ', output)

if __name__ == '__main__':
    unittest.main()
