"""Keyboard builders. User keyboards are reply keyboards; management uses inline keyboards."""
from __future__ import annotations
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton

TYPE_LABELS = {
    "content": "📝 محتوى", "folder": "📁 قائمة", "multi": "📚 أكثر من محتوى",
    "random": "🔀 محتوى عشوائي", "info": "📋 طلب معلومات", "search": "🔎 بحث",
    "webapp": "🌐 ويب آب", "daily": "🎁 الهدية اليومية", "template": "📋 من قالب",
    "survey": "📊 استبيان", "code": "💻 كود", "mirror": "🪞 مرآة زر موجود",
}

ADMIN_SECTIONS = [
    ("⚙️ الإعدادات", "section:settings"), ("📝 المحتوى", "section:content"),
    ("👥 المستخدمين", "section:users"), ("🔐 الاشتراك", "section:subscription"),
    ("📢 التواصل", "section:communication"), ("💰 المالية", "section:finance"),
    ("🛠️ النظام والدعم", "section:system"),
]


def type_keyboard() -> InlineKeyboardMarkup:
    rows = []
    values = list(TYPE_LABELS.items())
    for i in range(0, len(values), 2):
        rows.append([InlineKeyboardButton(label, callback_data=f"newtype:{kind}") for kind, label in values[i:i+2]])
    rows.append([InlineKeyboardButton("✖️ إلغاء", callback_data="cancel")])
    return InlineKeyboardMarkup(rows)


def admin_keyboard() -> ReplyKeyboardMarkup:
    rows = [[KeyboardButton("📝 المحتوى"), KeyboardButton("⚙️ إعدادات التحكم")],
            [KeyboardButton("👥 المستخدمين"), KeyboardButton("🔐 الاشتراك")],
            [KeyboardButton("📢 التواصل"), KeyboardButton("💰 المالية")],
            [KeyboardButton("🛠️ النظام والدعم"), KeyboardButton("↩️ واجهة المستخدم")],
            [KeyboardButton("0 | +"), KeyboardButton("1 | +")],
            [KeyboardButton("2 | +"), KeyboardButton("END | +")]]
    return ReplyKeyboardMarkup(rows, resize_keyboard=True, is_persistent=True)


def user_keyboard(buttons: list, is_admin: bool = False, db=None) -> ReplyKeyboardMarkup:
    labels = []
    for row in buttons:
        if not row["enabled"] or row["kind"] in ("template", "mirror"):
            continue
        label = str(row["name"])
        if db is not None:
            icon = str(db.get_settings(int(row["id"])).get("icon", "")).strip()
            if icon:
                label = f"{icon} {label}"
        labels.append(label)
    rows = [labels[i:i+2] for i in range(0, len(labels), 2)]
    if is_admin:
        rows.append(["⚙️ إعدادات التحكم"])
    return ReplyKeyboardMarkup(rows or [["/start"]], resize_keyboard=True, is_persistent=True)


def panel_keyboard() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton("⚙️ الإعدادات", callback_data="admin:settings"), InlineKeyboardButton("📝 المحتوى", callback_data="admin:content")],
        [InlineKeyboardButton("👥 المستخدمين", callback_data="admin:users"), InlineKeyboardButton("🔐 الاشتراك", callback_data="admin:subscriptions")],
        [InlineKeyboardButton("📢 التواصل", callback_data="admin:communication"), InlineKeyboardButton("💰 المالية", callback_data="admin:finance")],
        [InlineKeyboardButton("🛠️ النظام والدعم", callback_data="admin:system"), InlineKeyboardButton("📊 الإحصائيات", callback_data="admin:stats")],
        [InlineKeyboardButton("🔘 إدارة الأزرار", callback_data="admin:buttons"), InlineKeyboardButton("➕ إضافة زر", callback_data="admin:add")],
        [InlineKeyboardButton("💾 النسخ الاحتياطي", callback_data="admin:backup"), InlineKeyboardButton("❓ دليل الاستخدام", callback_data="admin:help")],
    ]
    return InlineKeyboardMarkup(rows)


def button_management_keyboard(button_id: int, enabled: bool) -> InlineKeyboardMarkup:
    status = "⏸ تعطيل" if enabled else "▶️ تفعيل"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📤 معاينة", callback_data=f"preview:{button_id}"), InlineKeyboardButton("✏️ إعادة تسمية", callback_data=f"rename:{button_id}")],
        [InlineKeyboardButton("⚙️ المزيد من الخيارات", callback_data=f"more:{button_id}"), InlineKeyboardButton("📋 حفظ كقالب", callback_data=f"template_save:{button_id}")],
        [InlineKeyboardButton("📥 إضافة محتوى", callback_data=f"content_add:{button_id}"), InlineKeyboardButton("🗑 حذف محتوى", callback_data=f"content_del:{button_id}")],
        [InlineKeyboardButton("📁 نقل إلى قائمة", callback_data=f"move:{button_id}"), InlineKeyboardButton(status, callback_data=f"toggle:{button_id}")],
        [InlineKeyboardButton("🗑 حذف الزر", callback_data=f"delete:{button_id}"), InlineKeyboardButton("↩️ رجوع", callback_data="admin:buttons")],
    ])


def button_settings_keyboard(button_id: int, settings: dict) -> InlineKeyboardMarkup:
    fields = [("🔒 حماية", "protect"), ("🔇 صامت", "silent"), ("🔗 معاينة الرابط", "link_preview"),
              ("🫣 سبويلر", "spoiler"), ("📌 تثبيت", "pin"), ("🔔 تنبيه", "notify")]
    rows = []
    for label, key in fields:
        state = "✅" if settings.get(key, False) else "❌"
        rows.append([InlineKeyboardButton(f"{label}: {state}", callback_data=f"setting:{button_id}:{key}")])
    rows += [[InlineKeyboardButton("🕐 حذف بعد", callback_data=f"setting_value:{button_id}:delete_after"),
              InlineKeyboardButton("⏳ تبريد", callback_data=f"setting_value:{button_id}:cooldown")],
             [InlineKeyboardButton("⏰ الجدولة", callback_data=f"setting_value:{button_id}:schedule"),
              InlineKeyboardButton("😀 الأيقونة", callback_data=f"setting_value:{button_id}:icon")],
             [InlineKeyboardButton("📚 طريقة العرض", callback_data=f"setting_value:{button_id}:display_mode")],
             [InlineKeyboardButton("📊 التحليلات", callback_data=f"analytics:{button_id}"),
              InlineKeyboardButton("↩️ رجوع", callback_data=f"manage:{button_id}")]]
    return InlineKeyboardMarkup(rows)


def folder_keyboard(button_id: int, children: list) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(str(item["name"]), callback_data=f"open:{item['id']}")] for item in children]
    rows.append([InlineKeyboardButton("↩️ رجوع", callback_data=f"manage:{button_id}")])
    return InlineKeyboardMarkup(rows)
