"""ARCEN Button Bot Pro - Telegram bot entry point."""
from __future__ import annotations
import logging
import tempfile
from pathlib import Path
from telegram import Update, InputFile
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, MessageHandler, filters, ContextTypes
from config import load_config, setup_logging
from database import Database
from handlers.admin import callback_handler, is_admin, message_wizard
from handlers.user import start, panel_command, cancel_command, text_router, media_router, document_router, confirm_restore
from keyboards import admin_keyboard
from services.backup import create_backup

CONFIG = load_config()
setup_logging(CONFIG.get("log_level", "INFO"))
log = logging.getLogger("arcen")
DB = Database(CONFIG["database_path"])


def seed_admins() -> None:
    for uid in CONFIG.get("admin_ids", []):
        DB.execute("INSERT INTO admins(user_id,role,added_at) VALUES(?,?,?) ON CONFLICT(user_id) DO NOTHING", (uid, "admin", __import__("database").utc_now()))


async def post_init(application: Application) -> None:
    seed_admins()
    backup_channel = CONFIG.get("backup_channel_id")
    if backup_channel and application.job_queue:
        application.job_queue.run_repeating(auto_backup_job, interval=86400, first=86400, name="arcen-auto-backup")
        log.info("Automatic daily backups enabled for channel %s", backup_channel)
    log.info("ARCEN Button Bot started. Database: %s", CONFIG["database_path"])


async def auto_backup_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Create a daily .mkfrky backup and deliver it to the configured private channel."""
    channel_id = CONFIG.get("backup_channel_id")
    if not channel_id:
        return
    path = Path(tempfile.gettempdir()) / "ARCEN_Auto_Backup.mkfrky"
    try:
        create_backup(DB.export_snapshot(), path, str(CONFIG.get("backup_password", "")))
        with path.open("rb") as stream:
            await context.bot.send_document(chat_id=int(channel_id), document=InputFile(stream, filename="ARCEN_Auto_Backup.mkfrky"), caption="نسخة ARCEN الاحتياطية التلقائية كل 24 ساعة.")
        DB.log(0, "auto_backup_created", str(path.stat().st_size))
    except Exception:
        log.exception("Automatic backup failed")
    finally:
        try: path.unlink(missing_ok=True)
        except OSError: pass


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    log.exception("Unhandled Telegram handler error", exc_info=context.error)
    if isinstance(update, Update) and update.effective_message:
        try:
            await update.effective_message.reply_text("حدث خطأ غير متوقع. تم تسجيله للمراجعة دون عرض تفاصيل تقنية حساسة.")
        except Exception:
            pass


async def admin_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    # Show the normal entry flow first; admins can switch to the dedicated admin keyboard.
    await start(update, context, CONFIG, DB)


async def done_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    handled = await message_wizard(update, context, CONFIG, DB)
    if not handled and update.effective_message:
        await update.effective_message.reply_text("لا توجد خطوة تنتظر الإنهاء الآن.")


def main() -> None:
    if not CONFIG.get("bot_token"):
        raise SystemExit("ضع توكن البوت في config.json أو token.txt قبل التشغيل.")
    application = Application.builder().token(CONFIG["bot_token"]).post_init(post_init).build()
    application.add_handler(CommandHandler("start", admin_start))
    application.add_handler(CommandHandler("panel", lambda u, c: panel_command(u, c, CONFIG, DB)))
    application.add_handler(CommandHandler("cancel", cancel_command))
    application.add_handler(CommandHandler("done", done_command))
    application.add_handler(CommandHandler("confirm_restore", lambda u, c: confirm_restore(u, c, CONFIG, DB)))
    application.add_handler(CallbackQueryHandler(lambda u, c: callback_handler(u, c, CONFIG, DB)))
    application.add_handler(MessageHandler(filters.Document.ALL, lambda u, c: document_router(u, c, CONFIG, DB)))
    media_filter = filters.PHOTO | filters.VIDEO | filters.AUDIO | filters.VOICE | filters.VIDEO_NOTE | filters.ANIMATION | filters.Sticker.ALL | filters.CONTACT | filters.LOCATION | filters.Document.ALL
    application.add_handler(MessageHandler(media_filter & ~filters.COMMAND, lambda u, c: media_router(u, c, CONFIG, DB)))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, lambda u, c: text_router(u, c, CONFIG, DB)))
    application.add_error_handler(error_handler)
    application.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=False)


if __name__ == "__main__":
    main()
