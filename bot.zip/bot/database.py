"""SQLite persistence layer. All user-provided values are parameterized."""
from __future__ import annotations
import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

SCHEMA = r"""
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(
 user_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT, joined_at TEXT NOT NULL,
 last_seen TEXT NOT NULL, is_blocked INTEGER NOT NULL DEFAULT 0, points INTEGER NOT NULL DEFAULT 0,
 last_daily_claim TEXT
);
CREATE TABLE IF NOT EXISTS admins(user_id INTEGER PRIMARY KEY, role TEXT NOT NULL DEFAULT 'admin', added_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS folders(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, parent_id INTEGER REFERENCES folders(id) ON DELETE CASCADE,
 created_by INTEGER NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS buttons(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, kind TEXT NOT NULL, parent_folder_id INTEGER REFERENCES folders(id) ON DELETE SET NULL,
 enabled INTEGER NOT NULL DEFAULT 1, created_by INTEGER NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '', keyboard_position INTEGER NOT NULL DEFAULT 1000
);
CREATE INDEX IF NOT EXISTS idx_buttons_name ON buttons(name COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS idx_buttons_folder ON buttons(parent_folder_id);
CREATE TABLE IF NOT EXISTS button_contents(
 id INTEGER PRIMARY KEY AUTOINCREMENT, button_id INTEGER NOT NULL REFERENCES buttons(id) ON DELETE CASCADE,
 position INTEGER NOT NULL DEFAULT 0, content_type TEXT NOT NULL, text_value TEXT NOT NULL DEFAULT '', file_id TEXT NOT NULL DEFAULT '',
 file_unique_id TEXT NOT NULL DEFAULT '', entities_json TEXT NOT NULL DEFAULT '[]', created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_contents_button ON button_contents(button_id, position);
CREATE TABLE IF NOT EXISTS button_settings(
 button_id INTEGER PRIMARY KEY REFERENCES buttons(id) ON DELETE CASCADE, settings_json TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS templates(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, kind TEXT NOT NULL, data_json TEXT NOT NULL,
 created_by INTEGER NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS information_questions(
 id INTEGER PRIMARY KEY AUTOINCREMENT, button_id INTEGER NOT NULL REFERENCES buttons(id) ON DELETE CASCADE,
 position INTEGER NOT NULL, question TEXT NOT NULL, answer_type TEXT NOT NULL DEFAULT 'text'
);
CREATE TABLE IF NOT EXISTS information_requests(
 id INTEGER PRIMARY KEY AUTOINCREMENT, button_id INTEGER NOT NULL REFERENCES buttons(id) ON DELETE CASCADE,
 user_id INTEGER NOT NULL, answers_json TEXT NOT NULL DEFAULT '{}', status TEXT NOT NULL DEFAULT 'in_progress',
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS surveys(
 id INTEGER PRIMARY KEY AUTOINCREMENT, button_id INTEGER NOT NULL UNIQUE REFERENCES buttons(id) ON DELETE CASCADE,
 welcome_text TEXT NOT NULL DEFAULT '', end_text TEXT NOT NULL DEFAULT '', quiz_mode INTEGER NOT NULL DEFAULT 0,
 one_response INTEGER NOT NULL DEFAULT 1, reward_points INTEGER NOT NULL DEFAULT 0, pass_percent INTEGER NOT NULL DEFAULT 60,
 show_each_result INTEGER NOT NULL DEFAULT 0, show_correct INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS survey_questions(
 id INTEGER PRIMARY KEY AUTOINCREMENT, survey_id INTEGER NOT NULL REFERENCES surveys(id) ON DELETE CASCADE,
 position INTEGER NOT NULL, question_type TEXT NOT NULL, question TEXT NOT NULL, options_json TEXT NOT NULL DEFAULT '[]',
 correct_option INTEGER, required INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS survey_responses(
 id INTEGER PRIMARY KEY AUTOINCREMENT, survey_id INTEGER NOT NULL REFERENCES surveys(id) ON DELETE CASCADE,
 user_id INTEGER NOT NULL, answers_json TEXT NOT NULL DEFAULT '[]', score INTEGER NOT NULL DEFAULT 0,
 completed INTEGER NOT NULL DEFAULT 0, started_at TEXT NOT NULL, completed_at TEXT
);
CREATE TABLE IF NOT EXISTS survey_answers(
 id INTEGER PRIMARY KEY AUTOINCREMENT, response_id INTEGER NOT NULL REFERENCES survey_responses(id) ON DELETE CASCADE,
 question_id INTEGER NOT NULL REFERENCES survey_questions(id) ON DELETE CASCADE, answer_text TEXT NOT NULL DEFAULT '',
 is_correct INTEGER
);
CREATE TABLE IF NOT EXISTS button_usage(
 id INTEGER PRIMARY KEY AUTOINCREMENT, button_id INTEGER NOT NULL REFERENCES buttons(id) ON DELETE CASCADE,
 user_id INTEGER NOT NULL, used_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_usage_button ON button_usage(button_id);
CREATE TABLE IF NOT EXISTS audit_logs(
 id INTEGER PRIMARY KEY AUTOINCREMENT, actor_id INTEGER NOT NULL, action TEXT NOT NULL, details TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS subscriptions(
 id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER NOT NULL UNIQUE, title TEXT NOT NULL DEFAULT '',
 kind TEXT NOT NULL DEFAULT 'channel', invite_url TEXT NOT NULL DEFAULT '', enabled INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS auto_replies(
 id INTEGER PRIMARY KEY AUTOINCREMENT, keyword TEXT NOT NULL COLLATE NOCASE, response TEXT NOT NULL,
 enabled INTEGER NOT NULL DEFAULT 1, created_by INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS scheduled_jobs(
 id INTEGER PRIMARY KEY AUTOINCREMENT, button_id INTEGER NOT NULL REFERENCES buttons(id) ON DELETE CASCADE,
 starts_at TEXT, ends_at TEXT, enabled INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS points_log(
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, amount INTEGER NOT NULL, reason TEXT NOT NULL,
 created_at TEXT NOT NULL
);
"""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Database:
    """Thread-safe SQLite wrapper with short-lived connections."""
    def __init__(self, path: str | Path):
        self.path = str(path)
        self._lock = threading.RLock()
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as conn:
            conn.executescript(SCHEMA)
            self._migrate(conn)
            conn.commit()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path, timeout=20)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=20000")
        try:
            yield conn
        finally:
            conn.close()

    @staticmethod
    def _migrate(conn: sqlite3.Connection) -> None:
        """Apply additive migrations to databases created by earlier prototypes."""
        columns = {row["name"] for row in conn.execute("PRAGMA table_info(button_contents)").fetchall()}
        if "entities_json" not in columns:
            conn.execute("ALTER TABLE button_contents ADD COLUMN entities_json TEXT NOT NULL DEFAULT '[]'")
        button_columns = {row["name"] for row in conn.execute("PRAGMA table_info(buttons)").fetchall()}
        if "keyboard_position" not in button_columns:
            conn.execute("ALTER TABLE buttons ADD COLUMN keyboard_position INTEGER NOT NULL DEFAULT 1000")
        survey_columns = {row["name"] for row in conn.execute("PRAGMA table_info(survey_questions)").fetchall()}
        if "correct_option" not in survey_columns:
            conn.execute("ALTER TABLE survey_questions ADD COLUMN correct_option INTEGER")

    def execute(self, sql: str, params: tuple[Any, ...] = ()) -> int:
        with self._lock, self.connect() as conn:
            cur = conn.execute(sql, params)
            conn.commit()
            return int(cur.lastrowid or 0)

    def fetchone(self, sql: str, params: tuple[Any, ...] = ()) -> sqlite3.Row | None:
        with self.connect() as conn:
            return conn.execute(sql, params).fetchone()

    def fetchall(self, sql: str, params: tuple[Any, ...] = ()) -> list[sqlite3.Row]:
        with self.connect() as conn:
            return list(conn.execute(sql, params).fetchall())

    def transaction(self):
        return self.connect()

    def upsert_user(self, user_id: int, username: str | None, first_name: str) -> None:
        now = utc_now()
        self.execute("""INSERT INTO users(user_id,username,first_name,joined_at,last_seen)
          VALUES(?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET username=excluded.username,
          first_name=excluded.first_name,last_seen=excluded.last_seen""",
          (user_id, username or "", first_name or "", now, now))

    def user_count(self) -> int:
        row = self.fetchone("SELECT COUNT(*) AS n FROM users WHERE is_blocked=0")
        return int(row["n"] if row else 0)

    def get_button(self, button_id: int):
        return self.fetchone("SELECT * FROM buttons WHERE id=?", (button_id,))

    def list_buttons(self, parent_folder_id: int | None = None, enabled_only: bool = True):
        query = "SELECT * FROM buttons WHERE parent_folder_id IS ?"
        params: list[Any] = [parent_folder_id]
        if enabled_only:
            query += " AND enabled=1"
        query += " ORDER BY keyboard_position,id"
        return self.fetchall(query, tuple(params))

    def add_content(self, button_id: int, content_type: str, text_value: str = "", file_id: str = "", file_unique_id: str = "", entities_json: str = "[]") -> int:
        row = self.fetchone("SELECT COALESCE(MAX(position),-1)+1 AS p FROM button_contents WHERE button_id=?", (button_id,))
        position = int(row["p"] if row else 0)
        return self.execute("""INSERT INTO button_contents(button_id,position,content_type,text_value,file_id,file_unique_id,entities_json,created_at)
          VALUES(?,?,?,?,?,?,?,?)""", (button_id, position, content_type, text_value, file_id, file_unique_id, entities_json or "[]", utc_now()))

    def get_contents(self, button_id: int):
        return self.fetchall("SELECT * FROM button_contents WHERE button_id=? ORDER BY position,id", (button_id,))

    def get_settings(self, button_id: int) -> dict[str, Any]:
        row = self.fetchone("SELECT settings_json FROM button_settings WHERE button_id=?", (button_id,))
        if not row:
            return {}
        try:
            data = json.loads(row["settings_json"])
            return data if isinstance(data, dict) else {}
        except json.JSONDecodeError:
            return {}

    def set_settings(self, button_id: int, settings: dict[str, Any]) -> None:
        self.execute("""INSERT INTO button_settings(button_id,settings_json) VALUES(?,?)
          ON CONFLICT(button_id) DO UPDATE SET settings_json=excluded.settings_json""",
          (button_id, json.dumps(settings, ensure_ascii=False)))

    def log(self, actor_id: int, action: str, details: str = "") -> None:
        self.execute("INSERT INTO audit_logs(actor_id,action,details,created_at) VALUES(?,?,?,?)",
                     (actor_id, action[:100], details[:2000], utc_now()))

    def add_points(self, user_id: int, amount: int, reason: str) -> int:
        with self._lock, self.connect() as conn:
            conn.execute("UPDATE users SET points=MAX(0,points+?) WHERE user_id=?", (amount, user_id))
            conn.execute("INSERT INTO points_log(user_id,amount,reason,created_at) VALUES(?,?,?,?)",
                         (user_id, amount, reason[:200], utc_now()))
            conn.commit()
            row = conn.execute("SELECT points FROM users WHERE user_id=?", (user_id,)).fetchone()
            return int(row["points"] if row else 0)

    def search(self, term: str, limit: int = 20):
        needle = f"%{term[:100]}%"
        return self.fetchall("""SELECT id,name,kind,parent_folder_id,enabled FROM buttons
          WHERE name LIKE ? COLLATE NOCASE OR id IN (SELECT button_id FROM button_contents WHERE text_value LIKE ? COLLATE NOCASE)
          ORDER BY id DESC LIMIT ?""", (needle, needle, max(1, min(limit, 50))))

    def export_snapshot(self) -> dict[str, Any]:
        """Export application tables as JSON-safe rows for portable backups."""
        tables = ["users", "admins", "folders", "buttons", "button_contents", "button_settings",
                  "templates", "information_questions", "information_requests", "surveys", "survey_questions",
                  "survey_responses", "survey_answers", "button_usage", "audit_logs", "subscriptions",
                  "auto_replies", "settings", "scheduled_jobs", "points_log"]
        snapshot: dict[str, Any] = {"format": "ARCEN-MKFRKY", "version": 1, "created_at": utc_now(), "tables": {}}
        with self.connect() as conn:
            for table in tables:
                snapshot["tables"][table] = [dict(row) for row in conn.execute(f"SELECT * FROM {table}").fetchall()]
        return snapshot

    def restore_snapshot(self, snapshot: dict[str, Any]) -> None:
        if snapshot.get("format") != "ARCEN-MKFRKY" or not isinstance(snapshot.get("tables"), dict):
            raise ValueError("صيغة النسخة الاحتياطية غير معروفة")
        allowed = {"users", "admins", "folders", "buttons", "button_contents", "button_settings", "templates",
                   "information_questions", "information_requests", "surveys", "survey_questions", "survey_responses",
                   "survey_answers", "button_usage", "audit_logs", "subscriptions", "auto_replies", "settings",
                   "scheduled_jobs", "points_log"}
        tables = snapshot["tables"]
        if not set(tables).issubset(allowed):
            raise ValueError("تحتوي النسخة على جداول غير مسموحة")
        with self._lock, self.connect() as conn:
            conn.execute("PRAGMA foreign_keys=OFF")
            try:
                conn.execute("BEGIN IMMEDIATE")
                for table in reversed(list(allowed)):
                    conn.execute(f"DELETE FROM {table}")
                for table, rows in tables.items():
                    if not isinstance(rows, list):
                        raise ValueError(f"بيانات الجدول {table} تالفة")
                    for row in rows:
                        if not isinstance(row, dict):
                            raise ValueError("صف غير صالح في النسخة")
                        columns = list(row.keys())
                        if not columns or any(not c.replace("_", "").isalnum() for c in columns):
                            raise ValueError("أسماء أعمدة غير صالحة")
                        placeholders = ",".join("?" for _ in columns)
                        col_sql = ",".join(columns)
                        conn.execute(f"INSERT INTO {table} ({col_sql}) VALUES ({placeholders})", tuple(row[c] for c in columns))
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.execute("PRAGMA foreign_keys=ON")
