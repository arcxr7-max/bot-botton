"""Administrative callbacks and message-driven setup flows."""
from __future__ import annotations
import json
import logging
import random
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, InputFile, Update, WebAppInfo
from telegram.constants import ParseMode
from telegram.ext import ContextTypes
from database import utc_now
from keyboards import (TYPE_LABELS, type_keyboard, panel_keyboard, button_management_keyboard,
                       button_settings_keyboard, user_keyboard)
from services.backup import create_backup, read_backup
from services.content import message_content, content_summary, send_content, safe_code_html
from services.code_runner import run_python
from services.validation import parse_survey_question, validate_button_name, validate_https_url
from services.analytics import overall_stats, survey_summary, export_survey_csv
from services.scheduler import is_available
from services.surveys import question_markup, answer_is_correct

log = logging.getLogger(__name__)


def is_admin(user_id: int, config: dict, db) -> bool:
    return user_id in config.get("owner_ids", []) or user_id in config.get("admin_ids", []) or bool(db.fetchone("SELECT 1 FROM admins WHERE user_id=?", (user_id,)))


def is_owner(user_id: int, config: dict) -> bool:
    return user_id in config.get("owner_ids", [])


def _admin_home_text(db) -> str:
    users = int((db.fetchone("SELECT COUNT(*) n FROM users") or {"n": 0})["n"])
    active = int((db.fetchone("SELECT COUNT(*) n FROM users WHERE is_blocked=0") or {"n": 0})["n"])
    buttons = int((db.fetchone("SELECT COUNT(*) n FROM buttons") or {"n": 0})["n"])
    admins = int((db.fetchone("SELECT COUNT(*) n FROM admins") or {"n": 0})["n"])
    state_row = db.fetchone("SELECT value FROM settings WHERE key='bot_enabled'")
    state = (state_row["value"] if state_row else "1") == "1"
    return ("⚙️ **لوحة إدارة ARCEN**\n\n"
            f"👥 المستخدمون: {users}\n✅ النشطون: {active}\n"
            f"🔘 الأزرار: {buttons}\n🛡 المسؤولون المسجلون: {admins}\n"
            f"🤖 حالة البوت: {'🟢 يعمل' if state else '🔴 متوقف للمستخدمين'}\n\n"
            "اختر القسم الذي تريد إدارته من الأزرار بالأسفل.")


async def open_panel(update: Update, context: ContextTypes.DEFAULT_TYPE, config: dict, db) -> None:
    user = update.effective_user
    if not user or not is_admin(user.id, config, db):
        if update.callback_query:
            await update.callback_query.answer("هذه اللوحة للمشرفين فقط", show_alert=True)
        elif update.effective_message:
            await update.effective_message.reply_text("⛔ هذه الوظيفة للمشرفين فقط.")
        return
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(_admin_home_text(db), reply_markup=panel_keyboard(), parse_mode=ParseMode.MARKDOWN)
    else:
        await update.effective_message.reply_text(_admin_home_text(db), reply_markup=panel_keyboard(), parse_mode=ParseMode.MARKDOWN)


async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE, config: dict, db) -> None:
    query = update.callback_query
    if not query:
        return
    data = query.data or ""
    user_id = query.from_user.id
    admin = is_admin(user_id, config, db)
    if data.startswith("multi_nav:"):
        try:
            _, bid_text, index_text = data.split(":", 2)
            bid, index = int(bid_text), int(index_text)
        except ValueError:
            await query.answer("طلب تنقل غير صالح", show_alert=True); return
        row = db.get_button(bid)
        if not row or not row["enabled"]:
            await query.answer("هذا الزر غير متاح", show_alert=True); return
        items = db.get_contents(bid)
        if not items:
            await query.answer("لا يوجد محتوى", show_alert=True); return
        index = max(0, min(index, len(items)-1))
        await query.answer(f"المحتوى {index+1} من {len(items)}")
        await send_content(context.bot, query.message.chat_id, items[index], db.get_settings(bid))
        nav = []
        if index > 0: nav.append(InlineKeyboardButton("⬅️ السابق", callback_data=f"multi_nav:{bid}:{index-1}"))
        if index < len(items)-1: nav.append(InlineKeyboardButton("التالي ➡️", callback_data=f"multi_nav:{bid}:{index+1}"))
        await query.edit_message_text(f"📚 {row['name']}\nالمحتوى {index+1} من {len(items)}", reply_markup=InlineKeyboardMarkup([nav] if nav else [[InlineKeyboardButton("↩️ القائمة", callback_data="admin:panel")]]))
        return
    if data.startswith("survey_pick:"):
        try:
            _, rid_text, qidx_text, option_text = data.split(":", 3)
            rid, qidx, option_idx = int(rid_text), int(qidx_text), int(option_text)
        except ValueError:
            await query.answer("إجابة غير صالحة", show_alert=True); return
        flow = context.user_data.get("survey_flow")
        if not flow or int(flow.get("response_id", -1)) != rid or int(flow.get("index", -1)) != qidx:
            await query.answer("انتهت جلسة الاستبيان. اضغط على زر الاستبيان مجددًا.", show_alert=True); return
        question = flow["questions"][qidx]
        try: options = json.loads(question.get("options_json") or "[]")
        except json.JSONDecodeError: options = []
        if question.get("question_type") == "rating": options = [str(number) for number in range(1, 6)]
        if option_idx < 0 or option_idx >= len(options):
            await query.answer("الخيار غير صالح", show_alert=True); return
        answer = str(options[option_idx])
        correct = answer_is_correct(question, option_idx) if int(db.fetchone("SELECT quiz_mode FROM surveys WHERE id=?", (flow["survey_id"],))["quiz_mode"]) else None
        if correct: flow["score"] += 1
        flow["answers"].append({"question_id": question["id"], "answer": answer, "correct": correct})
        flow["index"] += 1
        await query.answer("تم تسجيل إجابتك")
        if flow["index"] < len(flow["questions"]):
            next_question = flow["questions"][flow["index"]]
            markup = question_markup(next_question, rid, flow["index"])
            await query.message.reply_text(next_question["question"], reply_markup=markup)
            return
        db.execute("UPDATE survey_responses SET answers_json=?,completed=1,completed_at=?,score=? WHERE id=?", (json.dumps(flow["answers"], ensure_ascii=False), utc_now(), flow["score"], rid))
        for ans in flow["answers"]:
            db.execute("INSERT INTO survey_answers(response_id,question_id,answer_text,is_correct) VALUES(?,?,?,?)", (rid, ans["question_id"], ans["answer"], None if ans["correct"] is None else int(bool(ans["correct"]))))
        survey = db.fetchone("SELECT * FROM surveys WHERE id=?", (flow["survey_id"],))
        if survey and int(survey["reward_points"] or 0) > 0:
            db.add_points(query.from_user.id, int(survey["reward_points"]), "survey_reward")
        end_text = (survey["end_text"] if survey else "") or "شكرًا لمشاركتك!"
        if survey and survey["quiz_mode"]:
            end_text += f"\n\nنتيجتك: {flow['score']} من {len(flow['questions'])}."
        context.user_data.pop("survey_flow", None)
        await query.message.reply_text(end_text)
        return
    if data == "subscription:check":
        from services.subscriptions import check_membership, subscription_keyboard
        ok, missing = await check_membership(context.bot, query.from_user.id, db)
        await query.answer("تم التحقق" if ok else "لم يكتمل الاشتراك", show_alert=not ok)
        if not ok:
            await query.message.reply_text("اشترك في القنوات المطلوبة ثم اضغط تحقّق.", reply_markup=subscription_keyboard(missing))
        else:
            await query.message.reply_text("✅ تم التحقق من اشتراكك. أرسل /start لعرض القائمة.")
        return
    if data == "cancel":
        context.user_data.pop("wizard", None)
        await query.answer("تم الإلغاء")
        await query.edit_message_text("تم إلغاء العملية.")
        return
    if data.startswith("newtype:"):
        if not admin:
            await query.answer("للمشرفين فقط", show_alert=True); return
        kind = data.split(":", 1)[1]
        await query.answer()
        if kind == "mirror":
            rows = db.fetchall("SELECT id,name,kind FROM buttons WHERE enabled=1 ORDER BY id DESC LIMIT 40")
            kb = [[InlineKeyboardButton(f"🪞 {r['name']} · #{r['id']}", callback_data=f"mirror_use:{r['id']}")] for r in rows]
            kb.append([InlineKeyboardButton("✖️ إلغاء", callback_data="cancel")])
            await query.edit_message_text("اختر زرًا لإنشاء نسخة مستقلة منه:", reply_markup=InlineKeyboardMarkup(kb))
            return
        if kind == "template":
            rows = db.fetchall("SELECT id,name,kind FROM templates ORDER BY id DESC LIMIT 30")
            kb = [[InlineKeyboardButton(f"📋 {r['name']} ({r['kind']})", callback_data=f"template_use:{r['id']}")] for r in rows]
            kb.append([InlineKeyboardButton("✖️ إلغاء", callback_data="cancel")])
            await query.edit_message_text("اختر قالبًا لإنشاء نسخة مستقلة منه:", reply_markup=InlineKeyboardMarkup(kb))
            return
        context.user_data["wizard"] = {"step": "name", "kind": kind}
        await query.edit_message_text(f"{TYPE_LABELS.get(kind, kind)}\n\nأرسل الآن اسم الزر.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("✖️ إلغاء", callback_data="cancel")]]))
        return
    if not admin and data.split(":", 1)[0] in {"admin", "manage", "more", "setting", "setting_value", "rename", "toggle", "delete", "preview", "template_save", "content_add", "content_del", "move", "analytics", "folder_create", "backup_restore", "broadcast_send", "sub_add", "sub_del", "survey", "user_manage", "user_block", "settings", "global_toggle", "global_set", "admin_role", "admin_role_set", "autoreply_toggle", "autoreply_add"}:
        await query.answer("هذه الوظيفة للمشرفين فقط", show_alert=True); return
    if data == "admin:panel":
        await open_panel(update, context, config, db); return
    if data.startswith("admin:"):
        action = data.split(":", 1)[1]
        await query.answer()
        if action == "add":
            await query.edit_message_text("اختر نوع الزر:", reply_markup=type_keyboard())
        elif action == "buttons":
            rows = db.fetchall("SELECT id,name,kind,enabled FROM buttons ORDER BY id DESC LIMIT 40")
            buttons = [[InlineKeyboardButton(f"{'🟢' if r['enabled'] else '⏸'} {r['name']} · #{r['id']}", callback_data=f"manage:{r['id']}")] for r in rows]
            buttons.append([InlineKeyboardButton("➕ إضافة زر", callback_data="admin:add"), InlineKeyboardButton("↩️ القائمة", callback_data="admin:panel")])
            await query.edit_message_text("🗂 **إدارة الأزرار**\nاختر زرًا لتعديله:", reply_markup=InlineKeyboardMarkup(buttons), parse_mode=ParseMode.MARKDOWN)
        elif action == "folders":
            rows = db.fetchall("SELECT id,name,parent_id FROM folders ORDER BY id DESC LIMIT 40")
            buttons = [[InlineKeyboardButton(f"📁 {r['name']} · #{r['id']}", callback_data=f"folder_manage:{r['id']}")] for r in rows]
            buttons += [[InlineKeyboardButton("➕ مجلد جديد", callback_data="folder_create"), InlineKeyboardButton("↩️ القائمة", callback_data="admin:panel")]]
            await query.edit_message_text("📁 إدارة المجلدات:", reply_markup=InlineKeyboardMarkup(buttons))
        elif action == "templates":
            rows = db.fetchall("SELECT id,name,kind FROM templates ORDER BY id DESC LIMIT 40")
            buttons = [[InlineKeyboardButton(f"📋 {r['name']} ({r['kind']})", callback_data=f"template_use:{r['id']}")] for r in rows]
            buttons += [[InlineKeyboardButton("↩️ القائمة", callback_data="admin:panel")]]
            await query.edit_message_text("📋 القوالب المحفوظة. اضغط على قالب لإنشاء نسخة منه:", reply_markup=InlineKeyboardMarkup(buttons))
        elif action == "stats":
            users = db.fetchone("SELECT COUNT(*) n FROM users")['n']
            buttons = db.fetchone("SELECT COUNT(*) n FROM buttons")['n']
            content = db.fetchone("SELECT COUNT(*) n FROM button_contents")['n']
            usage = db.fetchone("SELECT COUNT(*) n FROM button_usage")['n']
            await query.edit_message_text(f"📊 **إحصائيات ARCEN**\n\n👥 المستخدمون: {users}\n🔘 الأزرار: {buttons}\n📦 عناصر المحتوى: {content}\n🖱 الاستخدامات المسجلة: {usage}", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("↩️ القائمة", callback_data="admin:panel")]]), parse_mode=ParseMode.MARKDOWN)
        elif action == "settings":
            state_row = db.fetchone("SELECT value FROM settings WHERE key='bot_enabled'")
            enabled = (state_row["value"] if state_row else "1") == "1"
            state_label = "⏹ إيقاف البوت للمستخدمين" if enabled else "▶️ تشغيل البوت للمستخدمين"
            await query.edit_message_text("⚙️ **إعدادات البوت**\n\nيمكن للمطور وحده تجاوز وضع الإيقاف. بقية المستخدمين والمشرفين لن يتمكنوا من استخدام وظائف البوت أثناء إيقافه.", parse_mode=ParseMode.MARKDOWN, reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton(state_label, callback_data="global_toggle:bot_enabled")],
                [InlineKeyboardButton("✏️ رسالة الترحيب", callback_data="setting_global:welcome_text")],
                [InlineKeyboardButton("🎁 نقاط الهدية اليومية", callback_data="setting_global:daily_reward_points")],
                [InlineKeyboardButton("🔐 إعدادات التحقق", callback_data="settings:verification")],
                [InlineKeyboardButton("🔒 حماية المحتوى", callback_data="settings:protection")],
                [InlineKeyboardButton("🔔 الإشعارات", callback_data="settings:notifications")],
                [InlineKeyboardButton("🧹 الحذف التلقائي", callback_data="settings:auto_delete")],
                [InlineKeyboardButton("💾 إنشاء نسخة", callback_data="admin:backup")],
                [InlineKeyboardButton("↩️ القائمة", callback_data="admin:panel")]]))
        elif action == "admins":
            if not is_owner(user_id, config):
                await query.answer("إدارة المسؤولين متاحة للمطور فقط", show_alert=True); return
            rows = db.fetchall("SELECT user_id,role FROM admins ORDER BY added_at DESC LIMIT 50")
            kb = [[InlineKeyboardButton(f"👤 {r['user_id']} · {r['role']}", callback_data=f"admin_role:{r['user_id']}")] for r in rows]
            kb += [[InlineKeyboardButton("➕ إضافة مسؤول", callback_data="admin:add_admin")], [InlineKeyboardButton("↩️ رجوع", callback_data="admin:users")]]
            await query.edit_message_text("🛡 **المسؤولون والصلاحيات**\nاختر مسؤولًا لتعديل دوره أو أضف مسؤولًا جديدًا.", reply_markup=InlineKeyboardMarkup(kb), parse_mode=ParseMode.MARKDOWN)
        elif action == "bans":
            rows = db.fetchall("SELECT user_id,username,first_name FROM users WHERE is_blocked=1 ORDER BY last_seen DESC LIMIT 50")
            kb = [[InlineKeyboardButton(f"🚫 {r['first_name'] or 'مستخدم'} · {r['user_id']}", callback_data=f"user_manage:{r['user_id']}")] for r in rows]
            kb += [[InlineKeyboardButton("🔍 بحث عن مستخدم", callback_data="admin:user_search")], [InlineKeyboardButton("↩️ رجوع", callback_data="admin:users")]]
            await query.edit_message_text("🚫 قائمة المستخدمين المحظورين\n\n" + ("\n".join(f"• {r['user_id']} @{r['username'] or 'بدون_اسم'}" for r in rows) or "القائمة فارغة."), reply_markup=InlineKeyboardMarkup(kb))
        elif action == "finance_stats":
            total = int((db.fetchone("SELECT COUNT(*) n FROM users") or {"n": 0})["n"])
            await query.edit_message_text(f"📊 الإحصائيات المالية\n\n💰 الإيرادات: $0.00 (لا توجد بوابة دفع مفعلة)\n👥 المستخدمون المسجلون: {total}\n🧾 المعاملات: 0", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("↩️ رجوع", callback_data="admin:finance")]]))
        elif action == "auto_replies":
            rows = db.fetchall("SELECT id,keyword,enabled FROM auto_replies ORDER BY id DESC LIMIT 30")
            kb = [[InlineKeyboardButton(f"{'✅' if r['enabled'] else '⏸'} {r['keyword']}", callback_data=f"autoreply_toggle:{r['id']}")] for r in rows]
            kb += [[InlineKeyboardButton("➕ إضافة رد تلقائي", callback_data="autoreply_add")], [InlineKeyboardButton("↩️ رجوع", callback_data="admin:content")]]
            await query.edit_message_text("💬 الردود التلقائية", reply_markup=InlineKeyboardMarkup(kb))
        elif action == "add_admin":
            if not is_owner(user_id, config):
                await query.answer("للمطور فقط", show_alert=True); return
            context.user_data["wizard"] = {"step": "add_admin_id"}
            await query.edit_message_text("أرسل Telegram User ID للمسؤول الجديد. لا ترسل رمز تسجيل الدخول أو كلمة مرور.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("✖️ إلغاء", callback_data="cancel")]]))
        elif action == "backup":
            await send_backup(query, context, config, db)
        elif action == "search":
            context.user_data["wizard"] = {"step": "search"}
            await query.edit_message_text("🔎 أرسل كلمة البحث. سيبحث البوت في أسماء الأزرار والنصوص المخزنة.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("إلغاء", callback_data="cancel")]]))
        elif action == "broadcast":
            context.user_data["wizard"] = {"step": "broadcast"}
            await query.edit_message_text("📢 أرسل رسالة الإذاعة. استخدم /cancel للإلغاء.")
        elif action == "subscriptions":
            rows = db.fetchall("SELECT * FROM subscriptions ORDER BY id DESC")
            buttons = [[InlineKeyboardButton(f"{'✅' if r['enabled'] else '⏸'} {r['title']} · {r['chat_id']}", callback_data=f"sub_toggle:{r['id']}")] for r in rows]
            buttons += [[InlineKeyboardButton("➕ إضافة قناة", callback_data="sub_add"), InlineKeyboardButton("↩️ القائمة", callback_data="admin:panel")]]
            await query.edit_message_text("🔐 قنوات الاشتراك الإجباري:", reply_markup=InlineKeyboardMarkup(buttons))
        elif action == "logs":
            rows = db.fetchall("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 12")
            body = "🧾 **آخر العمليات**\n\n" + ("\n".join(f"• {r['created_at']} | {r['actor_id']} | {r['action']} | {r['details'][:60]}" for r in rows) or "لا توجد سجلات بعد.")
            await query.edit_message_text(body, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("↩️ القائمة", callback_data="admin:panel")]]), parse_mode=ParseMode.MARKDOWN)
        elif action == "help":
            await query.edit_message_text("❓ **مساعدة الإدارة**\n\n➕ إضافة زر: اختر النوع ثم الاسم والمحتوى.\n📚 المحتوى المتعدد والعشوائي: أرسل عدة عناصر ثم اضغط إنهاء.\n📁 القائمة: أنشئ قائمة ثم أضف أزرارًا داخلها من إدارة الزر.\n💾 النسخ الاحتياطي: يصدر ملف `.mkfrky`.\n\nأكواد Python تُحفظ وتُعرض منسقة ولا تُنفذ داخل عملية البوت.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("↩️ القائمة", callback_data="admin:panel")]]), parse_mode=ParseMode.MARKDOWN)
        elif action == "user_search":
            context.user_data["wizard"] = {"step": "user_search"}
            await query.edit_message_text("أرسل معرّف المستخدم أو اسمه أو username للبحث:")
        elif action in {"content", "users", "communication", "finance", "system"}:
            sections = {
                "content": [["رسالة الترحيب", "setting_global:welcome_text"], ["الردود التلقائية", "admin:auto_replies"], ["الأزرار الشفافة", "admin:buttons"], ["تعديل الأزرار", "admin:buttons"], ["الاختصارات والأوامر", "admin:help"], ["إدارة الأزرار", "admin:buttons"], ["القوالب", "admin:templates"], ["بحث عام", "admin:search"]],
                "users": [["قائمة المستخدمين", "admin:user_search"], ["بحث عن مستخدم", "admin:user_search"], ["المسؤولون والصلاحيات", "admin:admins"], ["إدارة الحظر", "admin:bans"], ["سجل النشاط", "admin:logs"], ["الإحصائيات", "admin:stats"]],
                "communication": [["إذاعة سريعة", "admin:broadcast"], ["الإذاعة", "admin:broadcast"], ["الاشتراك الإجباري", "admin:subscriptions"]],
                "finance": [["الإحصائيات المالية", "admin:finance_stats"], ["الهدية اليومية والنقاط", "daily:admin"]],
                "system": [["النسخ الاحتياطي", "admin:backup"], ["السجلات", "admin:logs"], ["إعدادات البوت", "admin:settings"], ["قناة التحديثات", "admin:help"]],
            }
            buttons = [[InlineKeyboardButton(label, callback_data=cb)] for label, cb in sections[action]]
            buttons.append([InlineKeyboardButton("↩️ القائمة", callback_data="admin:panel")])
            await query.edit_message_text(f"قسم {action}", reply_markup=InlineKeyboardMarkup(buttons))
        return
    if data.startswith("admin_role:"):
        if not is_owner(user_id, config):
            await query.answer("إدارة الصلاحيات متاحة للمطور فقط", show_alert=True); return
        target = int(data.split(":", 1)[1])
        row = db.fetchone("SELECT role FROM admins WHERE user_id=?", (target,))
        if not row:
            await query.answer("المسؤول غير موجود", show_alert=True); return
        await query.answer()
        await query.edit_message_text(f"🛡 صلاحيات المسؤول {target}\nالدور الحالي: {row['role']}\n\nاختر الدور:", reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🛠️ مدير", callback_data=f"admin_role_set:{target}:admin")],
            [InlineKeyboardButton("📝 مدير محتوى", callback_data=f"admin_role_set:{target}:content")],
            [InlineKeyboardButton("👁️ مشرف محدود", callback_data=f"admin_role_set:{target}:moderator")],
            [InlineKeyboardButton("🗑 إزالة المسؤول", callback_data=f"admin_role_set:{target}:remove")],
            [InlineKeyboardButton("↩️ رجوع", callback_data="admin:admins")]])); return
    if data.startswith("admin_role_set:"):
        if not is_owner(user_id, config):
            await query.answer("للمطور فقط", show_alert=True); return
        _, target_text, role = data.split(":", 2); target = int(target_text)
        if target in config.get("owner_ids", []):
            await query.answer("لا يمكن تعديل المطور من هنا", show_alert=True); return
        if role == "remove":
            db.execute("DELETE FROM admins WHERE user_id=?", (target,))
            db.log(user_id, "admin_removed", str(target))
            await query.answer("تمت إزالة المسؤول")
        elif role in {"admin", "content", "moderator"}:
            db.execute("UPDATE admins SET role=? WHERE user_id=?", (role, target))
            db.log(user_id, "admin_role_changed", f"{target}:{role}")
            await query.answer("تم تحديث الدور")
        else:
            await query.answer("دور غير صالح", show_alert=True); return
        await query.edit_message_text("🛡 تم تحديث المسؤولين.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("↩️ قائمة المسؤولين", callback_data="admin:admins")]])); return
    if data == "autoreply_add":
        context.user_data["wizard"] = {"step": "autoreply_keyword"}
        await query.answer()
        await query.edit_message_text("💬 أرسل الكلمة أو العبارة التي ستُشغّل الرد التلقائي.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("✖️ إلغاء", callback_data="cancel")]])); return
    if data.startswith("autoreply_toggle:"):
        rid = int(data.split(":", 1)[1])
        row = db.fetchone("SELECT enabled FROM auto_replies WHERE id=?", (rid,))
        if not row:
            await query.answer("الرد غير موجود", show_alert=True); return
        db.execute("UPDATE auto_replies SET enabled=? WHERE id=?", (0 if row["enabled"] else 1, rid))
        await query.answer("تم تحديث الرد")
        await query.edit_message_text("💬 تم تحديث حالة الرد التلقائي.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("↩️ الردود التلقائية", callback_data="admin:auto_replies")]])); return
    if data.startswith("user_manage:"):
        from services.members import user_detail
        uid = int(data.split(":")[1]); detail = user_detail(db, uid)
        if not detail:
            await query.answer("المستخدم غير موجود", show_alert=True); return
        status = "محظور" if detail["is_blocked"] else "نشط"
        await query.answer()
        await query.edit_message_text(f"👤 المستخدم {uid}\nالاسم: {detail['first_name']}\nالمعرّف: @{detail['username'] or 'لا يوجد'}\nالحالة: {status}\nالنقاط: {detail['points']}\nاستخدامات الأزرار: {detail['button_uses']}", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🚫 حظر" if not detail['is_blocked'] else "✅ فك الحظر", callback_data=f"user_block:{uid}:{0 if not detail['is_blocked'] else 1}")], [InlineKeyboardButton("↩️ نتائج البحث", callback_data="admin:user_search")]])); return
    if data.startswith("user_block:"):
        from services.members import set_blocked
        _, uid_text, blocked_text = data.split(":", 2); uid, blocked = int(uid_text), bool(int(blocked_text))
        if set_blocked(db, uid, blocked, user_id):
            await query.answer("تم تحديث حالة المستخدم")
            detail = db.fetchone("SELECT * FROM users WHERE user_id=?", (uid,))
            await query.edit_message_text(f"تم {'حظر' if blocked else 'فك حظر'} المستخدم {uid}.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("عرض المستخدم", callback_data=f"user_manage:{uid}")], [InlineKeyboardButton("لوحة الإدارة", callback_data="admin:panel")]]))
        else: await query.answer("المستخدم غير موجود", show_alert=True)
        return
    if data.startswith("manage:"):
        bid = int(data.split(":")[1]); row = db.get_button(bid)
        if not row:
            await query.answer("الزر غير موجود", show_alert=True); return
        await query.answer()
        kb = button_management_keyboard(bid, bool(row['enabled']))
        if row['kind'] == "survey":
            kb = InlineKeyboardMarkup(kb.inline_keyboard + [[InlineKeyboardButton("📊 إدارة الاستبيان", callback_data=f"survey_admin:{bid}")]])
        await query.edit_message_text(f"🔘 **{row['name']}**\nالنوع: `{row['kind']}`\nالمعرّف: `{bid}`\nالحالة: {'مفعّل' if row['enabled'] else 'معطّل'}", reply_markup=kb, parse_mode=ParseMode.MARKDOWN)
        return
    if data.startswith("more:"):
        bid = int(data.split(":")[1]); await query.answer()
        await query.edit_message_text("⚙️ المزيد من الخيارات لهذا الزر:", reply_markup=button_settings_keyboard(bid, db.get_settings(bid))); return
    if data.startswith("setting:"):
        _, bid_text, key = data.split(":", 2); bid = int(bid_text)
        settings = db.get_settings(bid); settings[key] = not bool(settings.get(key, False)); db.set_settings(bid, settings)
        db.log(user_id, "button_setting_toggle", f"{bid}:{key}={settings[key]}")
        await query.answer("تم تحديث الإعداد")
        await query.edit_message_reply_markup(reply_markup=button_settings_keyboard(bid, settings)); return
    if data.startswith("setting_value:"):
        _, bid_text, key = data.split(":", 2)
        context.user_data["wizard"] = {"step": "button_setting_value", "button_id": int(bid_text), "key": key}
        labels = {"delete_after": "عدد الثواني قبل حذف الرسالة (0 للإيقاف)", "cooldown": "مدة التبريد بالثواني (0 للإيقاف)", "schedule": "أرسل وقت البداية بصيغة ISO مثل 2026-12-01T10:00:00 أو اكتب off", "icon": "أرسل إيموجي الأيقونة", "display_mode": "اختر طريقة العرض: classic أو carousel أو list"}
        await query.answer(); await query.message.reply_text(labels.get(key, "أرسل القيمة الجديدة:")); return
    if data.startswith("rename:"):
        bid = int(data.split(":")[1]); context.user_data["wizard"] = {"step": "rename", "button_id": bid}
        await query.answer(); await query.message.reply_text("أرسل الاسم الجديد للزر:"); return
    if data.startswith("toggle:"):
        bid = int(data.split(":")[1]); row = db.get_button(bid)
        if row:
            db.execute("UPDATE buttons SET enabled=?,updated_at=? WHERE id=?", (0 if row['enabled'] else 1, utc_now(), bid))
            db.log(user_id, "button_toggle", str(bid))
        await query.answer("تم تحديث الحالة")
        row = db.get_button(bid)
        await query.edit_message_reply_markup(reply_markup=button_management_keyboard(bid, bool(row['enabled']))); return
    if data.startswith("delete:"):
        bid = int(data.split(":")[1]); await query.answer()
        await query.edit_message_text("⚠️ هل تريد حذف الزر ومحتواه المرتبط؟", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("نعم، احذف", callback_data=f"delete_confirm:{bid}"), InlineKeyboardButton("إلغاء", callback_data=f"manage:{bid}")]])); return
    if data.startswith("delete_confirm:"):
        bid = int(data.split(":")[1]); db.execute("DELETE FROM buttons WHERE id=?", (bid,)); db.log(user_id, "button_deleted", str(bid))
        await query.answer("تم الحذف"); await query.edit_message_text("🗑 تم حذف الزر.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("إدارة الأزرار", callback_data="admin:buttons")]])); return
    if data.startswith("preview:"):
        bid = int(data.split(":")[1]); await query.answer()
        items = db.get_contents(bid)
        if not items:
            await query.message.reply_text("لا يوجد محتوى محفوظ لهذا الزر.")
        else:
            for item in items:
                await send_content(context.bot, query.message.chat_id, item, db.get_settings(bid))
        return
    if data.startswith("content_add:"):
        bid = int(data.split(":")[1]); context.user_data["wizard"] = {"step": "append_content", "button_id": bid}
        await query.answer(); await query.message.reply_text("أرسل المحتوى أو الوسائط. اضغط إنهاء عند الانتهاء.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("✅ إنهاء", callback_data="wizard_done")]])); return
    if data == "wizard_done":
        context.user_data.pop("wizard", None); await query.answer("تم إنهاء الإضافة")
        await query.message.reply_text("تم حفظ المحتوى.", reply_markup=panel_keyboard()); return
    if data.startswith("content_del:"):
        bid = int(data.split(":")[1]); rows = db.get_contents(bid)
        kb = [[InlineKeyboardButton(f"🗑 {i+1}. {content_summary(r)}", callback_data=f"content_delete:{r['id']}:{bid}")] for i, r in enumerate(rows)]
        kb.append([InlineKeyboardButton("↩️ رجوع", callback_data=f"manage:{bid}")])
        await query.answer(); await query.edit_message_text("اختر عنصر المحتوى الذي تريد حذفه:", reply_markup=InlineKeyboardMarkup(kb)); return
    if data.startswith("content_delete:"):
        _, cid, bid = data.split(":"); db.execute("DELETE FROM button_contents WHERE id=?", (int(cid),)); await query.answer("حُذف المحتوى")
        await query.edit_message_text("تم حذف عنصر المحتوى.", reply_markup=button_management_keyboard(int(bid), bool(db.get_button(int(bid))['enabled']))); return
    if data.startswith("template_save:"):
        bid = int(data.split(":")[1]); row = db.get_button(bid); items = db.get_contents(bid); settings = db.get_settings(bid)
        payload = {"name": row['name'], "kind": row['kind'], "description": row['description'], "settings": settings,
                   "contents": [dict(x) for x in items]}
        context.user_data["wizard"] = {"step": "template_name", "payload": payload, "button_id": bid}
        await query.answer(); await query.message.reply_text("أرسل اسم القالب الذي تريد حفظه:"); return
    if data.startswith("mirror_use:"):
        source_id = int(data.split(":")[1]); source = db.get_button(source_id)
        if not source:
            await query.answer("الزر غير موجود", show_alert=True); return
        new_id = db.execute("INSERT INTO buttons(name,kind,parent_folder_id,created_by,created_at,updated_at,description) VALUES(?,?,?,?,?,?,?)", (source['name']+" (نسخة)", source['kind'], source['parent_folder_id'], user_id, utc_now(), utc_now(), source['description']))
        db.set_settings(new_id, db.get_settings(source_id))
        for item in db.get_contents(source_id):
            db.add_content(new_id, item['content_type'], item['text_value'], item['file_id'], item['file_unique_id'], item['entities_json'] if 'entities_json' in item.keys() else "[]")
        db.log(user_id, "button_mirrored", f"{source_id}->{new_id}")
        await query.answer("تم إنشاء نسخة مستقلة")
        await query.edit_message_text(f"🪞 تم نسخ الزر #{source_id} إلى #{new_id}.", reply_markup=button_management_keyboard(new_id, True)); return
    if data.startswith("template_use:"):
        tid = int(data.split(":")[1]); row = db.fetchone("SELECT * FROM templates WHERE id=?", (tid,))
        if not row:
            await query.answer("القالب غير موجود", show_alert=True); return
        payload = json.loads(row['data_json'])
        bid = db.execute("INSERT INTO buttons(name,kind,created_by,created_at,updated_at,description) VALUES(?,?,?,?,?,?)",
                         (payload['name']+" (نسخة)", payload['kind'], user_id, utc_now(), utc_now(), payload.get('description','')))
        db.set_settings(bid, payload.get('settings', {}))
        for item in payload.get('contents', []):
            db.add_content(bid, item['content_type'], item['text_value'], item['file_id'], item['file_unique_id'], item.get('entities_json', "[]"))
        db.log(user_id, "template_used", f"{tid}->{bid}")
        await query.answer("تم إنشاء نسخة مستقلة")
        await query.edit_message_text(f"تم إنشاء نسخة من القالب كزر #{bid}.", reply_markup=button_management_keyboard(bid, True)); return
    if data.startswith("analytics:"):
        bid = int(data.split(":")[1]); uses = db.fetchone("SELECT COUNT(*) n FROM button_usage WHERE button_id=?", (bid,))['n']
        users = db.fetchone("SELECT COUNT(DISTINCT user_id) n FROM button_usage WHERE button_id=?", (bid,))['n']
        await query.answer(); await query.edit_message_text(f"📊 تحليلات الزر #{bid}\n\nالاستخدامات: {uses}\nالمستخدمون المختلفون: {users}", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("↩️ رجوع", callback_data=f"more:{bid}")]])); return
    if data == "folder_create":
        context.user_data["wizard"] = {"step": "folder_name"}; await query.answer(); await query.message.reply_text("أرسل اسم المجلد:"); return
    if data.startswith("folder_manage:"):
        fid = int(data.split(":")[1]); children = db.fetchall("SELECT id,name,kind FROM buttons WHERE parent_folder_id=? ORDER BY id", (fid,))
        kb = [[InlineKeyboardButton(f"{r['name']} · #{r['id']}", callback_data=f"manage:{r['id']}")] for r in children]
        kb += [[InlineKeyboardButton("➕ إضافة زر داخل المجلد", callback_data=f"folder_add:{fid}")], [InlineKeyboardButton("↩️ رجوع", callback_data="admin:folders")]]
        await query.answer(); await query.edit_message_text(f"📁 المجلد #{fid}", reply_markup=InlineKeyboardMarkup(kb)); return
    if data.startswith("folder_add:"):
        fid = int(data.split(":")[1]); context.user_data["folder_target"] = fid
        await query.answer(); await query.edit_message_text("اختر نوع الزر الذي تريد إضافته داخل المجلد:", reply_markup=type_keyboard()); return
    if data.startswith("sub_add"):
        context.user_data["wizard"] = {"step": "subscription_chat"}; await query.answer(); await query.message.reply_text("أرسل معرّف القناة/المجموعة مثل -100123456789 أو @publicchannel:"); return
    if data.startswith("sub_toggle:"):
        sid = int(data.split(":")[1]); row = db.fetchone("SELECT enabled FROM subscriptions WHERE id=?", (sid,))
        if row: db.execute("UPDATE subscriptions SET enabled=? WHERE id=?", (0 if row['enabled'] else 1, sid))
        await query.answer("تم تحديث الاشتراك"); await query.edit_message_text("تم تحديث الحالة. افتح قسم الاشتراك لعرض القائمة.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("↩️ رجوع", callback_data="admin:subscriptions")]])); return
    if data.startswith("global_toggle:"):
        key = data.split(":", 1)[1]
        if key == "bot_enabled":
            if not is_owner(user_id, config):
                await query.answer("هذا الإعداد متاح للمطور فقط", show_alert=True); return
            current = db.fetchone("SELECT value FROM settings WHERE key='bot_enabled'")
            enabled = (current["value"] if current else "1") == "1"
            db.execute("INSERT INTO settings(key,value) VALUES('bot_enabled',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", ("0" if enabled else "1",))
            db.log(user_id, "bot_enabled_changed", "0" if enabled else "1")
            await query.answer("تم تحديث حالة البوت")
            await query.edit_message_text(_admin_home_text(db), reply_markup=panel_keyboard(), parse_mode=ParseMode.MARKDOWN)
        return
    if data.startswith("settings:"):
        section = data.split(":", 1)[1]
        descriptions = {
            "verification": ("🔐 قسم التحقق", "اختر نظام التحقق المناسب. CAPTCHA والويب والهاتف والدعوات والموافقة اليدوية تحتاج إعدادات تنفيذ مستقلة قبل تفعيلها فعليًا."),
            "protection": ("🔒 حماية المحتوى", "تمنع حماية المحتوى إعادة التوجيه والحفظ في الرسائل المدعومة. الاستثناءات تُدار لكل نوع محتوى."),
            "notifications": ("🔔 الإشعارات", "تتحكم بإشعارات دخول المستخدمين وحظرهم."),
            "auto_delete": ("🧹 الحذف التلقائي", "تحديد مدة حذف الرسائل يحتاج ضبطًا قبل تشغيله. لا يتم حذف رسائل المحادثة بأثر رجعي."),
        }
        title, body = descriptions.get(section, ("الإعدادات", ""))
        keys = {
            "verification": [("⭕ معطل", "verification_mode", "off"), ("🔐 CAPTCHA", "verification_mode", "captcha"), ("✋ موافقة", "verification_mode", "approval")],
            "protection": [("🔒 حماية المحتوى", "content_protection", "1"), ("🔓 تعطيل الحماية", "content_protection", "0")],
            "notifications": [("🔔 إشعار الدخول", "notify_join", "1"), ("🔕 إيقاف إشعار الدخول", "notify_join", "0"), ("🚫 إشعار الحظر", "notify_ban", "1"), ("🔕 إيقاف إشعار الحظر", "notify_ban", "0")],
            "auto_delete": [("🧹 حذف تلقائي", "auto_delete_enabled", "1"), ("⏸ تعطيل الحذف", "auto_delete_enabled", "0")],
        }
        rows = []
        for label, key, value in keys.get(section, []):
            rows.append([InlineKeyboardButton(label, callback_data=f"global_set:{key}:{value}")])
        rows.append([InlineKeyboardButton("↩️ إعدادات البوت", callback_data="admin:settings")])
        await query.answer()
        await query.edit_message_text(f"{title}\n\n{body}", reply_markup=InlineKeyboardMarkup(rows))
        return
    if data.startswith("global_set:"):
        _, key, value = data.split(":", 2)
        db.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
        db.log(user_id, "setting_changed", f"{key}={value}")
        await query.answer("تم حفظ الإعداد")
        await query.edit_message_text(f"✅ تم حفظ الإعداد: {key} = {value}", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("↩️ إعدادات البوت", callback_data="admin:settings")]]))
        return
    if data.startswith("setting_global:"):
        key = data.split(":", 1)[1]; context.user_data["wizard"] = {"step": "global_setting", "key": key}
        await query.answer(); await query.message.reply_text("أرسل القيمة الجديدة:"); return
    if data.startswith("daily:"):
        await query.answer(); await query.edit_message_text("🎁 الهدية اليومية تعتمد على نقاط المكافأة في config.json. يستطيع المستخدم المطالبة بها مرة كل يوم UTC.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("تعديل النقاط", callback_data="setting_global:daily_reward_points")], [InlineKeyboardButton("↩️ القائمة", callback_data="admin:panel")]])); return
    if data.startswith("survey_admin:"):
        bid = int(data.split(":")[1]); survey = db.fetchone("SELECT * FROM surveys WHERE button_id=?", (bid,))
        if not survey:
            await query.answer("لا يوجد إعداد استبيان", show_alert=True); return
        await query.answer()
        await query.edit_message_text("📊 إعدادات الاستبيان", reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton(f"🎯 وضع الاختبار: {'✅' if survey['quiz_mode'] else '❌'}", callback_data=f"survey_toggle:{survey['id']}:quiz_mode")],
            [InlineKeyboardButton(f"🔒 مرة واحدة: {'✅' if survey['one_response'] else '❌'}", callback_data=f"survey_toggle:{survey['id']}:one_response")],
            [InlineKeyboardButton("🪙 مكافأة النقاط", callback_data=f"survey_value:{survey['id']}:reward_points")],
            [InlineKeyboardButton("✏️ رسالة الترحيب", callback_data=f"survey_value:{survey['id']}:welcome_text")],
            [InlineKeyboardButton("✉️ رسالة الإنهاء", callback_data=f"survey_value:{survey['id']}:end_text")],
            [InlineKeyboardButton("📈 النتائج", callback_data=f"survey_results:{survey['id']}")],
            [InlineKeyboardButton("📥 تصدير CSV", callback_data=f"survey_export:{survey['id']}")],
            [InlineKeyboardButton("↩️ رجوع", callback_data=f"manage:{bid}")]])); return
    if data.startswith("survey_toggle:"):
        _, sid_text, key = data.split(":", 2); sid = int(sid_text)
        if key not in {"quiz_mode", "one_response"}:
            await query.answer("إعداد غير صالح", show_alert=True); return
        survey = db.fetchone("SELECT * FROM surveys WHERE id=?", (sid,))
        if not survey:
            await query.answer("الاستبيان غير موجود", show_alert=True); return
        db.execute(f"UPDATE surveys SET {key}=? WHERE id=?", (0 if survey[key] else 1, sid))
        await query.answer("تم تحديث الإعداد")
        bid = int(survey['button_id'])
        await query.edit_message_text("📊 تم تحديث إعداد الاستبيان.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("إعدادات الاستبيان", callback_data=f"survey_admin:{bid}")]])); return
    if data.startswith("survey_value:"):
        _, sid_text, key = data.split(":", 2)
        if key not in {"reward_points", "welcome_text", "end_text"}:
            await query.answer("إعداد غير صالح", show_alert=True); return
        context.user_data["wizard"] = {"step": "survey_setting", "survey_id": int(sid_text), "key": key}
        await query.answer(); await query.message.reply_text("أرسل القيمة الجديدة:"); return
    if data.startswith("survey_results:"):
        sid = int(data.split(":")[1]); summary = survey_summary(db, sid)
        text = f"📊 النتائج\nبدأ: {summary['started']}\nأكمل: {summary['completed']}\n\n"
        for item in summary['questions']:
            text += f"**{item['question']}**\n" + ("\n".join(f"• {a}: {n}" for a,n in item['answers']) or "لا توجد إجابات") + "\n\n"
        await query.answer(); await query.edit_message_text(text[:4000], parse_mode=ParseMode.MARKDOWN, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("↩️ رجوع", callback_data=f"survey_admin:{db.fetchone('SELECT button_id FROM surveys WHERE id=?',(sid,))['button_id']}")]])); return
    if data.startswith("survey_export:"):
        sid = int(data.split(":")[1]); from telegram import InputFile; import io
        payload = export_survey_csv(db, sid)
        await query.answer("تم تجهيز CSV")
        await context.bot.send_document(query.message.chat_id, document=InputFile(io.BytesIO(payload), filename=f"arcen_survey_{sid}.csv"), caption="تصدير إجابات الاستبيان")
        return
    if data.startswith("open:"):
        bid = int(data.split(":")[1]); await query.answer(); await deliver_button(update, context, config, db, bid); return
    if data.startswith("info_answer:"):
        await query.answer(); return


async def message_wizard(update: Update, context: ContextTypes.DEFAULT_TYPE, config: dict, db) -> bool:
    """Consume a pending admin wizard message. Returns True when it handled the message."""
    message = update.effective_message
    user = update.effective_user
    if not message or not user:
        return False
    wizard = context.user_data.get("wizard")
    if not wizard:
        return False
    if message.text and message.text.strip() == "/cancel":
        context.user_data.pop("wizard", None); await message.reply_text("تم إلغاء العملية."); return True
    if not is_admin(user.id, config, db):
        context.user_data.pop("wizard", None); return False
    step = wizard.get("step")
    if step == "add_admin_id":
        if not is_owner(user.id, config):
            context.user_data.pop("wizard", None)
            await message.reply_text("هذه العملية للمطور فقط."); return True
        try:
            target = int(message.text.strip())
            if target <= 0: raise ValueError
        except ValueError:
            await message.reply_text("أرسل User ID رقميًا صحيحًا."); return True
        db.execute("INSERT INTO admins(user_id,role,added_at) VALUES(?,?,?) ON CONFLICT(user_id) DO NOTHING", (target, "admin", utc_now()))
        db.log(user.id, "admin_added", str(target))
        context.user_data.pop("wizard", None)
        await message.reply_text(f"✅ تمت إضافة المسؤول {target}.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🛡 المسؤولون", callback_data="admin:admins")]])); return True
    if step == "autoreply_keyword":
        keyword = message.text.strip()[:100]
        if not keyword:
            await message.reply_text("أرسل كلمة غير فارغة."); return True
        context.user_data["wizard"] = {"step": "autoreply_response", "keyword": keyword}
        await message.reply_text(f"الكلمة: {keyword}\nأرسل نص الرد التلقائي الآن."); return True
    if step == "autoreply_response":
        keyword = str(wizard.get("keyword", ""))
        db.execute("INSERT INTO auto_replies(keyword,response,enabled,created_by) VALUES(?,?,1,?)", (keyword, message.text[:4000], user.id))
        db.log(user.id, "auto_reply_added", keyword)
        context.user_data.pop("wizard", None)
        await message.reply_text(f"✅ تم حفظ الرد التلقائي للكلمة: {keyword}", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("↩️ الردود التلقائية", callback_data="admin:auto_replies")]])); return True
    if step == "user_search":
        from services.members import search_users
        term = (message.text or "").strip()
        rows = search_users(db, term, 25)
        context.user_data.pop("wizard", None)
        kb = [[InlineKeyboardButton(f"{r['first_name'] or 'مستخدم'} · {r['user_id']} · {'محظور' if r['is_blocked'] else 'نشط'}", callback_data=f"user_manage:{r['user_id']}")] for r in rows]
        kb.append([InlineKeyboardButton("↩️ لوحة الإدارة", callback_data="admin:panel")])
        await message.reply_text(f"نتائج البحث: {len(rows)}", reply_markup=InlineKeyboardMarkup(kb)); return True
    if step == "folder_name":
        name = (message.text or "").strip()[:64]
        if not name:
            await message.reply_text("أرسل اسمًا صالحًا للمجلد."); return True
        db.execute("INSERT INTO folders(name,parent_id,created_by,created_at) VALUES(?,?,?,?)", (name, None, user.id, utc_now()))
        db.log(user.id, "folder_created", name)
        context.user_data.pop("wizard", None)
        await message.reply_text(f"📁 تم إنشاء المجلد: {name}", reply_markup=panel_keyboard()); return True
    if step == "name":
        valid_name, name = validate_button_name(message.text or "")
        if not valid_name:
            await message.reply_text(name); return True
        kind = wizard["kind"]
        parent = context.user_data.pop("folder_target", None)
        position = wizard.get("keyboard_position")
        if position is None:
            pos_row = db.fetchone("SELECT COALESCE(MAX(keyboard_position),-1)+1 AS p FROM buttons WHERE parent_folder_id IS ?", (parent,))
            position = int(pos_row["p"] if pos_row else 0)
        elif int(position) >= 0:
            db.execute("UPDATE buttons SET keyboard_position=keyboard_position+1 WHERE parent_folder_id IS ? AND keyboard_position>=?", (parent, int(position)))
        bid = db.execute("INSERT INTO buttons(name,kind,parent_folder_id,created_by,created_at,updated_at,keyboard_position) VALUES(?,?,?,?,?,?,?)",
                         (name, kind, parent, user.id, utc_now(), utc_now(), int(position)))
        settings = {"protect": False, "silent": False, "link_preview": True, "spoiler": False, "pin": False, "notify": False, "delete_after": 0, "cooldown": 0}
        if kind == "folder":
            folder_id = db.execute("INSERT INTO folders(name,parent_id,created_by,created_at) VALUES(?,?,?,?)", (name, parent, user.id, utc_now()))
            settings["folder_id"] = folder_id
        db.set_settings(bid, settings)
        db.log(user.id, "button_created", f"{bid}:{kind}:{name}")
        wizard["button_id"] = bid
        if kind == "folder":
            context.user_data.pop("wizard", None)
            await message.reply_text(f"📁 تم إنشاء القائمة: {name} (#{bid}).\nأضف أزرارًا داخلها من إدارة الأزرار.", reply_markup=panel_keyboard()); return True
        if kind == "daily":
            context.user_data.pop("wizard", None)
            await message.reply_text(f"🎁 تم إنشاء زر الهدية اليومية: {name}. سيتم إرسال المكافأة المحددة في الإعدادات.", reply_markup=panel_keyboard()); return True
        if kind == "template":
            context.user_data["wizard"] = {"step": "template_select"}
            rows = db.fetchall("SELECT id,name FROM templates ORDER BY id DESC LIMIT 30")
            kb = [[InlineKeyboardButton(r['name'], callback_data=f"template_use:{r['id']}")] for r in rows]
            if not kb: context.user_data.pop("wizard", None); await message.reply_text("لا توجد قوالب محفوظة بعد."); return True
            await message.reply_text("اختر قالبًا من الأزرار:", reply_markup=InlineKeyboardMarkup(kb)); return True
        if kind == "search":
            context.user_data["wizard"] = {"step": "search"}; await message.reply_text("أرسل كلمة البحث:"); return True
        if kind == "webapp":
            context.user_data["wizard"] = {"step": "webapp_url", "button_id": bid}; await message.reply_text("أرسل رابط HTTPS لتطبيق الويب:"); return True
        if kind == "info":
            context.user_data["wizard"] = {"step": "info_questions", "button_id": bid, "questions": []}
            await message.reply_text("أرسل السؤال الأول لطلب المعلومات. أرسل /done عند الانتهاء."); return True
        if kind == "survey":
            sid = db.execute("INSERT INTO surveys(button_id,welcome_text,end_text,quiz_mode,one_response,reward_points,pass_percent,show_each_result,show_correct) VALUES(?,?,?,?,?,?,?,?,?)",
                             (bid, "", "شكرًا لمشاركتك!", 0, 1, 0, 60, 0, 1))
            context.user_data["wizard"] = {"step": "survey_question", "button_id": bid, "survey_id": sid, "questions": []}
            await message.reply_text("أرسل نص السؤال الأول للاستبيان، أو /done لإنهائه. الأسئلة المضافة هنا نصية؛ يمكنك إدارة الخيارات لاحقًا من لوحة الاستبيان."); return True
        context.user_data["wizard"] = {"step": "content", "button_id": bid, "kind": kind, "count": 0}
        await message.reply_text(f"📝 أرسل الآن محتوى الزر: ({name})\n\nيمكنك إرسال نص أو صورة أو فيديو أو ملف أو صوت أو ملصق. أرسل عدة عناصر إذا أردت. اضغط إنهاء عند الانتهاء.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("✅ إنهاء وحفظ", callback_data="wizard_done")]]))
        return True
    if step in {"content", "append_content"}:
        bid = int(wizard["button_id"])
        if message.text and message.text.strip().lower() in {"/done", "تم", "انهاء", "إنهاء"}:
            context.user_data.pop("wizard", None); await message.reply_text("✅ تم حفظ المحتوى.", reply_markup=panel_keyboard()); return True
        item = message_content(message)
        if not (item["text_value"] or item["file_id"]):
            await message.reply_text("لم أتعرف على محتوى صالح. أرسل نصًا أو وسائط مدعومة."); return True
        if wizard.get("kind") == "code":
            item["content_type"] = "text"
            item["text_value"] = message.text or message.caption or ""
            if not item["text_value"]:
                await message.reply_text("نوع الكود يقبل النص البرمجي. أرسل الكود كنص، مع الحفاظ على الأسطر والمسافات."); return True
        db.add_content(bid, item["content_type"], item["text_value"], item["file_id"], item["file_unique_id"], item.get("entities_json", "[]"))
        wizard["count"] = int(wizard.get("count", 0)) + 1
        await message.reply_text(f"✅ أُضيف العنصر #{wizard['count']}. أرسل عنصرًا آخر أو اضغط إنهاء.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("✅ إنهاء وحفظ", callback_data="wizard_done")]]))
        return True
    if step == "info_questions":
        if message.text and message.text.strip().lower() in {"/done", "تم"}:
            bid = int(wizard["button_id"]); questions = wizard["questions"]
            if not questions:
                await message.reply_text("أضف سؤالًا واحدًا على الأقل قبل الإنهاء."); return True
            for idx, question in enumerate(questions):
                db.execute("INSERT INTO information_questions(button_id,position,question,answer_type) VALUES(?,?,?,?)", (bid, idx, question, "text"))
            context.user_data.pop("wizard", None)
            await message.reply_text(f"📋 تم حفظ {len(questions)} سؤالًا في زر طلب المعلومات.", reply_markup=panel_keyboard()); return True
        question = (message.text or "").strip()[:500]
        if not question:
            await message.reply_text("أرسل السؤال كنص أو اكتب /done."); return True
        wizard["questions"].append(question)
        await message.reply_text(f"تمت إضافة السؤال {len(wizard['questions'])}. أرسل السؤال التالي أو /done."); return True
    if step == "survey_question":
        if message.text and message.text.strip().lower() in {"/done", "تم"}:
            if not wizard["questions"]:
                await message.reply_text("أضف سؤالًا واحدًا على الأقل."); return True
            context.user_data.pop("wizard", None)
            await message.reply_text(f"📊 تم حفظ الاستبيان مع {len(wizard['questions'])} سؤال/أسئلة نصية.", reply_markup=panel_keyboard()); return True
        parsed = parse_survey_question(message.text or "")
        if not parsed.get("ok"):
            await message.reply_text(parsed.get("error", "صيغة السؤال غير صحيحة.")); return True
        pos = len(wizard["questions"])
        qid = db.execute("INSERT INTO survey_questions(survey_id,position,question_type,question,options_json,correct_option,required) VALUES(?,?,?,?,?,?,1)", (wizard["survey_id"], pos, parsed["type"], parsed["question"], json.dumps(parsed["options"], ensure_ascii=False), parsed.get("correct_option")))
        wizard["questions"].append(qid)
        await message.reply_text(f"تمت إضافة السؤال {len(wizard['questions'])} ({parsed['type']}). أرسل السؤال التالي أو /done.\nللاختياري: اختياري: السؤال | خيار 1 | خيار 2\nللرقمي: رقمي: السؤال\nللتقييم: تقييم: السؤال"); return True
    if step == "rename":
        name = (message.text or "").strip()[:64]
        if not name: await message.reply_text("الاسم لا يمكن أن يكون فارغًا."); return True
        bid = int(wizard["button_id"]); db.execute("UPDATE buttons SET name=?,updated_at=? WHERE id=?", (name, utc_now(), bid)); db.log(user.id, "button_renamed", f"{bid}:{name}")
        context.user_data.pop("wizard", None); await message.reply_text("تم تغيير الاسم.", reply_markup=panel_keyboard()); return True
    if step == "template_name":
        name = (message.text or "").strip()[:80]
        if not name: await message.reply_text("أرسل اسمًا صالحًا."); return True
        payload = wizard["payload"]
        db.execute("INSERT INTO templates(name,kind,data_json,created_by,created_at) VALUES(?,?,?,?,?)", (name, payload["kind"], json.dumps(payload, ensure_ascii=False), user.id, utc_now()))
        context.user_data.pop("wizard", None); db.log(user.id, "template_saved", name)
        await message.reply_text(f"📋 تم حفظ القالب: {name}", reply_markup=panel_keyboard()); return True
    if step == "search":
        term = (message.text or "").strip()
        if not term: await message.reply_text("أرسل كلمة بحث."); return True
        rows = db.search(term, 20)
        kb = [[InlineKeyboardButton(f"{r['name']} · #{r['id']}", callback_data=f"manage:{r['id']}")] for r in rows]
        kb.append([InlineKeyboardButton("↩️ لوحة الإدارة", callback_data="admin:panel")])
        context.user_data.pop("wizard", None)
        await message.reply_text(f"🔎 نتائج البحث عن {term!r}: {len(rows)}", reply_markup=InlineKeyboardMarkup(kb)); return True
    if step == "broadcast":
        text = message.text or message.caption or ""
        if not text: await message.reply_text("أرسل رسالة نصية للإذاعة في هذه النسخة."); return True
        context.user_data.pop("wizard", None)
        await message.reply_text("جارٍ بدء الإذاعة…")
        users = db.fetchall("SELECT user_id FROM users WHERE is_blocked=0")
        sent = failed = 0
        for row in users:
            try:
                await context.bot.send_message(int(row['user_id']), text)
                sent += 1
            except Exception:
                failed += 1
                db.execute("UPDATE users SET is_blocked=1 WHERE user_id=?", (int(row['user_id']),))
        db.log(user.id, "broadcast", f"sent={sent};failed={failed}")
        await message.reply_text(f"انتهت الإذاعة. وصل: {sent}، تعذر: {failed}.", reply_markup=panel_keyboard()); return True
    if step == "button_setting_value":
        bid, key = int(wizard["button_id"]), wizard["key"]
        settings = db.get_settings(bid); raw = (message.text or "").strip()
        if key in {"delete_after", "cooldown"}:
            try: value = max(0, min(int(raw), 86400 * 30))
            except ValueError: await message.reply_text("أرسل رقمًا صحيحًا بالثواني."); return True
            settings[key] = value
        elif key == "schedule":
            if raw.lower() == "off": settings.pop("schedule", None)
            else:
                try: datetime.fromisoformat(raw)
                except ValueError: await message.reply_text("صيغة الوقت غير صحيحة. مثال: 2026-12-01T10:00:00"); return True
                settings["schedule"] = raw
        elif key == "icon": settings["icon"] = raw[:12]
        elif key == "display_mode":
            if raw.lower() not in {"classic", "carousel", "list"}:
                await message.reply_text("استخدم classic أو carousel أو list."); return True
            settings[key] = raw.lower()
        db.set_settings(bid, settings); context.user_data.pop("wizard", None)
        await message.reply_text("تم حفظ الإعداد.", reply_markup=button_management_keyboard(bid, bool(db.get_button(bid)['enabled']))); return True
    if step == "survey_setting":
        sid, key = int(wizard["survey_id"]), wizard["key"]
        raw = (message.text or "").strip()
        if key == "reward_points":
            try: raw = max(0, min(int(raw), 100000))
            except ValueError: await message.reply_text("أرسل عدد نقاط صحيحًا."); return True
            db.execute("UPDATE surveys SET reward_points=? WHERE id=?", (raw, sid))
        elif key in {"welcome_text", "end_text"}:
            db.execute(f"UPDATE surveys SET {key}=? WHERE id=?", (raw[:1000], sid))
        context.user_data.pop("wizard", None)
        survey = db.fetchone("SELECT button_id FROM surveys WHERE id=?", (sid,))
        await message.reply_text("تم حفظ إعداد الاستبيان.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("إعدادات الاستبيان", callback_data=f"survey_admin:{survey['button_id']}")]])); return True
    if step == "global_setting":
        key = wizard["key"]; raw = (message.text or "").strip()
        if key == "daily_reward_points":
            try: raw = str(max(0, min(int(raw), 100000)))
            except ValueError: await message.reply_text("أرسل عددًا صحيحًا."); return True
        db.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, raw))
        context.user_data.pop("wizard", None); await message.reply_text("تم حفظ الإعداد.", reply_markup=panel_keyboard()); return True
    if step == "webapp_url":
        url = (message.text or "").strip()
        if not url.startswith("https://"):
            await message.reply_text("يجب أن يبدأ الرابط بـ https://"); return True
        bid = int(wizard["button_id"]); db.add_content(bid, "text", url); context.user_data.pop("wizard", None)
        await message.reply_text("تم حفظ رابط Web App. ملاحظة: فتح Web App يتطلب إعدادات Telegram المناسبة.", reply_markup=panel_keyboard()); return True
    if step == "subscription_chat":
        chat = (message.text or "").strip()
        try: chat_id = int(chat) if chat.lstrip("-").isdigit() else chat
        except ValueError: await message.reply_text("أرسل معرّفًا صحيحًا أو @username."); return True
        context.user_data["wizard"] = {"step": "subscription_title", "chat_id": chat_id}
        await message.reply_text("أرسل اسم القناة للعرض:"); return True
    if step == "subscription_title":
        title = (message.text or "").strip()[:100]
        if not title: await message.reply_text("أرسل اسم القناة."); return True
        wizard["title"] = title; wizard["step"] = "subscription_url"
        await message.reply_text("أرسل رابط الاشتراك (https://t.me/...) أو اكتب skip للقناة العامة:"); return True
    if step == "subscription_url":
        invite_url = (message.text or "").strip()
        if invite_url.lower() == "skip": invite_url = ""
        elif invite_url and not invite_url.startswith("https://t.me/"):
            await message.reply_text("أرسل رابطًا يبدأ بـ https://t.me/ أو اكتب skip."); return True
        db.execute("INSERT INTO subscriptions(chat_id,title,kind,invite_url,enabled) VALUES(?,?,?,?,1)", (wizard["chat_id"], wizard["title"], "channel", invite_url))
        context.user_data.pop("wizard", None); await message.reply_text("تمت إضافة القناة. تأكد أن البوت مشرف فيها ليتمكن من التحقق.", reply_markup=panel_keyboard()); return True
    return False


async def send_backup(query, context, config, db):
    password = str(config.get("backup_password", ""))
    tmp = Path(tempfile.gettempdir()) / f"arcen_backup_{query.from_user.id}.mkfrky"
    create_backup(db.export_snapshot(), tmp, password)
    await context.bot.send_document(chat_id=query.message.chat_id, document=InputFile(tmp.open("rb"), filename="ARCEN_Backup.mkfrky"), caption=("نسخة احتياطية مشفرة بكلمة المرور الموجودة في config.json." if password else "نسخة احتياطية غير مشفرة. احفظها في مكان آمن."))
    db.log(query.from_user.id, "backup_created", str(tmp.stat().st_size))


async def deliver_button(update: Update, context: ContextTypes.DEFAULT_TYPE, config: dict, db, bid: int):
    user = update.effective_user
    row = db.get_button(bid)
    if not row or not row["enabled"]:
        await update.effective_message.reply_text("هذا الزر غير متاح حاليًا."); return
    settings = db.get_settings(bid)
    now = datetime.now(timezone.utc)
    available, schedule_message = is_available(settings, now)
    if not available:
        await update.effective_message.reply_text(schedule_message); return
    cooldown = int(settings.get("cooldown", 0) or 0)
    if cooldown:
        last = db.fetchone("SELECT used_at FROM button_usage WHERE button_id=? AND user_id=? ORDER BY id DESC LIMIT 1", (bid, user.id))
        if last:
            try:
                elapsed = (now - datetime.fromisoformat(last['used_at'])).total_seconds()
                if elapsed < cooldown:
                    await update.effective_message.reply_text(f"انتظر {int(cooldown-elapsed)} ثانية قبل استخدام الزر مجددًا."); return
            except ValueError: pass
    db.execute("INSERT INTO button_usage(button_id,user_id,used_at) VALUES(?,?,?)", (bid, user.id, utc_now()))
    if settings.get("notify"):
        for owner_id in config.get("owner_ids", []):
            try: await context.bot.send_message(int(owner_id), f"🔔 استخدام زر: {row['name']}\nالمستخدم: {user.full_name} ({user.id})")
            except Exception: pass
    kind = row["kind"]
    if kind == "webapp":
        items = db.get_contents(bid)
        url = items[0]["text_value"].strip() if items else ""
        if not url.startswith("https://"):
            await update.effective_message.reply_text("رابط Web App غير مضبوط. افتح إعدادات الزر لتعديله."); return
        if update.effective_chat.type == "private":
            launch_button = InlineKeyboardButton("🌐 فتح التطبيق", web_app=WebAppInfo(url=url))
        else:
            launch_button = InlineKeyboardButton("🌐 فتح الرابط", url=url)
        await update.effective_message.reply_text(row["name"], reply_markup=InlineKeyboardMarkup([[launch_button]]))
        return
    if kind == "folder":
        folder_id = settings.get("folder_id")
        children = db.fetchall("SELECT id,name,kind FROM buttons WHERE parent_folder_id=? AND enabled=1 ORDER BY id", (folder_id,)) if folder_id else []
        kb = [[InlineKeyboardButton(str(c['name']), callback_data=f"open:{c['id']}")] for c in children]
        if not kb:
            await update.effective_message.reply_text("📁 هذه القائمة فارغة حاليًا."); return
        await update.effective_message.reply_text(f"📁 {row['name']}", reply_markup=InlineKeyboardMarkup(kb)); return
    if kind == "daily":
        user_row = db.fetchone("SELECT last_daily_claim FROM users WHERE user_id=?", (user.id,))
        today = now.date().isoformat()
        if user_row and user_row['last_daily_claim'] == today:
            await update.effective_message.reply_text("🎁 حصلت على هديتك اليومية بالفعل. ارجع غدًا!"); return
        reward_row = db.fetchone("SELECT value FROM settings WHERE key='daily_reward_points'")
        reward = int(reward_row['value']) if reward_row else int(config.get("daily_reward_points", 5))
        db.execute("UPDATE users SET last_daily_claim=? WHERE user_id=?", (today, user.id))
        total = db.add_points(user.id, reward, "daily_reward")
        await update.effective_message.reply_text(f"🎁 هديتك اليومية: +{reward} نقطة. رصيدك: {total}."); return
    if kind == "search":
        context.user_data["search_button"] = bid
        await update.effective_message.reply_text("🔎 أرسل كلمة البحث داخل محتويات البوت:"); return
    if kind == "info":
        questions = db.fetchall("SELECT question FROM information_questions WHERE button_id=? ORDER BY position", (bid,))
        if not questions:
            await update.effective_message.reply_text("لم يضف المشرف أسئلة إلى هذا الطلب بعد."); return
        req = db.execute("INSERT INTO information_requests(button_id,user_id,answers_json,status,created_at,updated_at) VALUES(?,?,?,?,?,?)", (bid, user.id, "[]", "in_progress", utc_now(), utc_now()))
        context.user_data["info_flow"] = {"request_id": req, "button_id": bid, "questions": [q['question'] for q in questions], "answers": [], "index": 0}
        await update.effective_message.reply_text("📋 " + questions[0]['question'] + "\n\nأرسل /cancel للإلغاء."); return
    if kind == "survey":
        survey = db.fetchone("SELECT * FROM surveys WHERE button_id=?", (bid,))
        if not survey:
            await update.effective_message.reply_text("الاستبيان غير مُعدّ بعد."); return
        if survey['one_response']:
            completed = db.fetchone("SELECT id FROM survey_responses WHERE survey_id=? AND user_id=? AND completed=1", (survey['id'], user.id))
            if completed:
                await update.effective_message.reply_text("لقد أجبت عن هذا الاستبيان مسبقًا."); return
        questions = db.fetchall("SELECT * FROM survey_questions WHERE survey_id=? ORDER BY position", (survey['id'],))
        if not questions:
            await update.effective_message.reply_text("لا توجد أسئلة في هذا الاستبيان."); return
        rid = db.execute("INSERT INTO survey_responses(survey_id,user_id,answers_json,score,completed,started_at) VALUES(?,?,?,?,0,?)", (survey['id'], user.id, "[]", 0, utc_now()))
        context.user_data['survey_flow'] = {"survey_id": survey['id'], "response_id": rid, "questions": [dict(q) for q in questions], "answers": [], "index": 0, "score": 0}
        first_markup = question_markup(dict(questions[0]), rid, 0)
        await update.effective_message.reply_text((survey['welcome_text'] + "\n\n" if survey['welcome_text'] else "") + questions[0]['question'], reply_markup=first_markup)
        return
    items = db.get_contents(bid)
    if not items:
        await update.effective_message.reply_text("لم يُضف محتوى لهذا الزر بعد."); return
    if kind == "random":
        items = [random.choice(items)]
    elif kind == "multi" and settings.get("display_mode") == "carousel":
        await send_content(context.bot, update.effective_chat.id, items[0], settings)
        nav = []
        if len(items) > 1: nav.append(InlineKeyboardButton("التالي ➡️", callback_data=f"multi_nav:{bid}:1"))
        await update.effective_message.reply_text(f"📚 {row['name']}\nالمحتوى 1 من {len(items)}", reply_markup=InlineKeyboardMarkup([nav] if nav else [[InlineKeyboardButton("↩️ القائمة", callback_data="admin:panel")]]))
        return
    elif kind == "multi" and settings.get("display_mode") == "list":
        kb = [[InlineKeyboardButton(f"{idx+1}. {content_summary(item)}", callback_data=f"multi_nav:{bid}:{idx}")] for idx, item in enumerate(items[:50])]
        await update.effective_message.reply_text(f"📚 {row['name']} · اختر محتوى:", reply_markup=InlineKeyboardMarkup(kb)); return
    elif kind == "code":
        # The owner/admins create and edit code buttons through the protected admin
        # wizard. Any user may press the published button and receive its output.
        import asyncio
        for item in items:
            code = item["text_value"] or ""
            ok, output = await asyncio.to_thread(run_python, code)

        if ok:
            await context.bot.send_message(
                update.effective_chat.id,
                output or "تم التنفيذ بنجاح.",
                protect_content=bool(settings.get("protect", False)),
            )
        else:
            await context.bot.send_message(
                update.effective_chat.id,
                f"تعذر تنفيذ الكود\n{output}",
                protect_content=bool(settings.get("protect", False)),
            )
        return
    sent_messages = []
    for item in items:
        result = await send_content(context.bot, update.effective_chat.id, item, settings)
        if result is not None:
            if isinstance(result, list):
                sent_messages.extend(result)
            else:
                sent_messages.append(result)
    if settings.get("pin"):
        for sent_message in sent_messages:
            try:
                await context.bot.pin_chat_message(chat_id=sent_message.chat_id, message_id=sent_message.message_id, disable_notification=True)
            except Exception:
                log.info("Pin was not permitted in chat %s", sent_message.chat_id)
    delete_after = int(settings.get("delete_after", 0) or 0)
    if delete_after and context.job_queue:
        for sent_message in sent_messages:
            context.job_queue.run_once(_delete_message_job, when=delete_after, data={"chat_id": sent_message.chat_id, "message_id": sent_message.message_id}, name=f"delete-content-{bid}-{sent_message.message_id}")


async def _delete_message_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    data = context.job.data or {}
    try:
        await context.bot.delete_message(chat_id=data["chat_id"], message_id=data["message_id"])
    except Exception:
        log.debug("Bot message was not deletable or was already removed")
