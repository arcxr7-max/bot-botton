"""Public-facing handlers, content delivery, surveys, and information requests."""
from __future__ import annotations
import json
import logging
from datetime import datetime, timezone
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, LinkPreviewOptions, Update
from telegram.constants import ParseMode
from telegram.ext import ContextTypes
from database import utc_now
from keyboards import user_keyboard, admin_keyboard, panel_keyboard
from services.content import send_content, message_content
from handlers.admin import is_admin, is_owner, deliver_button, message_wizard, open_panel
from services.backup import read_backup
from services.subscriptions import check_membership, subscription_keyboard
from services.surveys import question_markup, validate_answer

log = logging.getLogger(__name__)


def _effective_setting(db, key: str, default: str = "") -> str:
    row = db.fetchone("SELECT value FROM settings WHERE key=?", (key,))
    return str(row["value"]) if row else default


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE, config: dict, db) -> None:
    user = update.effective_user
    if not user or not update.effective_message:
        return
    db.upsert_user(user.id, user.username, user.first_name)
    admin = is_admin(user.id, config, db)
    enabled_row = db.fetchone("SELECT value FROM settings WHERE key='bot_enabled'")
    bot_enabled = (enabled_row["value"] if enabled_row else "1") == "1"
    if not bot_enabled and not is_owner(user.id, config):
        await update.effective_message.reply_text("⏸ البوت متوقف مؤقتًا من الإدارة. حاول لاحقًا.")
        return
    if not admin:
        subscriptions = db.fetchall("SELECT id FROM subscriptions WHERE enabled=1")
        if subscriptions:
            ok, missing = await check_membership(context.bot, user.id, db)
            if not ok:
                await update.effective_message.reply_text("🔐 قبل استخدام البوت، اشترك في القنوات المطلوبة ثم اضغط تحقّق.", reply_markup=subscription_keyboard(missing))
                return
    buttons = db.list_buttons(None, enabled_only=True)
    welcome = _effective_setting(db, "welcome_text", str(config.get("welcome_text", "أهلًا بك في بوت آركين.")))
    await update.effective_message.reply_text(welcome, reply_markup=user_keyboard(buttons, False, db))
    if admin:
        from keyboards import panel_keyboard
        from handlers.admin import _admin_home_text
        await update.effective_message.reply_text(_admin_home_text(db), reply_markup=panel_keyboard(), parse_mode=ParseMode.MARKDOWN)


async def panel_command(update: Update, context: ContextTypes.DEFAULT_TYPE, config: dict, db) -> None:
    await open_panel(update, context, config, db)


async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    context.user_data.pop("wizard", None)
    context.user_data.pop("info_flow", None)
    context.user_data.pop("survey_flow", None)
    context.user_data.pop("search_button", None)
    if update.effective_message:
        await update.effective_message.reply_text("تم إلغاء العملية الحالية.")


async def text_router(update: Update, context: ContextTypes.DEFAULT_TYPE, config: dict, db) -> None:
    message = update.effective_message
    user = update.effective_user
    if not message or not user or not message.text:
        return
    db.upsert_user(user.id, user.username, user.first_name)
    enabled_row = db.fetchone("SELECT value FROM settings WHERE key='bot_enabled'")
    bot_enabled = (enabled_row["value"] if enabled_row else "1") == "1"
    if not bot_enabled and not is_owner(user.id, config):
        if not is_admin(user.id, config, db):
            await message.reply_text("⏸ البوت متوقف مؤقتًا من الإدارة. حاول لاحقًا.")
        return
    if await message_wizard(update, context, config, db):
        return
    if message.text == "⚙️ إعدادات التحكم" or message.text == "/panel":
        await open_panel(update, context, config, db); return
    if message.text == "↩️ واجهة المستخدم":
        await message.reply_text("عدت إلى واجهة المستخدم.", reply_markup=user_keyboard(db.list_buttons(None), is_admin(user.id, config, db), db)); return
    if message.text in {"0 | +", "1 | +", "2 | +", "END | +"}:
        if not is_admin(user.id, config, db):
            await message.reply_text("هذه الوظيفة للمشرفين فقط."); return
        position = None if message.text == "END | +" else int(message.text.split("|")[0].strip())
        context.user_data["wizard"] = {"step": "name", "kind": "content", "keyboard_position": position}
        await message.reply_text(f"موضع الإضافة: {message.text}\n• أرسل الآن اسم الزر المراد إضافته.")
        return
    if message.text in {"📝 المحتوى", "⚙️ الإعدادات", "👥 المستخدمين", "🔐 الاشتراك", "📢 التواصل", "💰 المالية", "🛠️ النظام والدعم"}:
        if not is_admin(user.id, config, db):
            await message.reply_text("هذه القائمة للمشرفين فقط."); return
        mapping = {"📝 المحتوى": "content", "⚙️ الإعدادات": "settings", "👥 المستخدمين": "users", "🔐 الاشتراك": "subscriptions", "📢 التواصل": "communication", "💰 المالية": "finance", "🛠️ النظام والدعم": "system"}
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        section = mapping[message.text]
        await message.reply_text(f"قسم الإدارة: {message.text}", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("فتح القسم", callback_data=f"admin:{section}")], [InlineKeyboardButton("لوحة الإدارة", callback_data="admin:panel")]])); return
    info_flow = context.user_data.get("info_flow")
    if info_flow:
        if message.text.strip() == "/cancel":
            context.user_data.pop("info_flow", None); await message.reply_text("تم إلغاء طلب المعلومات."); return
        info_flow["answers"].append(message.text[:2000])
        info_flow["index"] += 1
        if info_flow["index"] < len(info_flow["questions"]):
            await message.reply_text(info_flow["questions"][info_flow["index"]]); return
        request_id = int(info_flow["request_id"])
        answers = list(zip(info_flow["questions"], info_flow["answers"]))
        db.execute("UPDATE information_requests SET answers_json=?,status='completed',updated_at=? WHERE id=?", (json.dumps(answers, ensure_ascii=False), utc_now(), request_id))
        report = ["📋 **طلب معلومات جديد**", f"المستخدم: {user.full_name} (`{user.id}`)"]
        report += [f"**{q}**\n{a}" for q, a in answers]
        destination = config.get("admin_contact_chat_id")
        if destination:
            try: await context.bot.send_message(int(destination), "\n\n".join(report), parse_mode=ParseMode.MARKDOWN)
            except Exception as exc: log.warning("Could not send information request: %s", exc)
        for owner_id in config.get("owner_ids", []):
            try: await context.bot.send_message(int(owner_id), "\n\n".join(report), parse_mode=ParseMode.MARKDOWN)
            except Exception: pass
        context.user_data.pop("info_flow", None); await message.reply_text("✅ تم إرسال إجاباتك إلى الإدارة. شكرًا لك!"); return
    survey_flow = context.user_data.get("survey_flow")
    if survey_flow:
        q = survey_flow["questions"][survey_flow["index"]]
        valid, answer_or_error = validate_answer(q, message.text)
        if not valid:
            await message.reply_text(answer_or_error); return
        answer = answer_or_error
        survey_flow["answers"].append({"question_id": q["id"], "answer": answer, "correct": None})
        survey_flow["index"] += 1
        if survey_flow["index"] < len(survey_flow["questions"]):
            next_question = survey_flow["questions"][survey_flow["index"]]
            markup = question_markup(next_question, survey_flow["response_id"], survey_flow["index"])
            await message.reply_text(next_question["question"], reply_markup=markup); return
        rid = survey_flow["response_id"]
        db.execute("UPDATE survey_responses SET answers_json=?,completed=1,completed_at=?,score=? WHERE id=?", (json.dumps(survey_flow["answers"], ensure_ascii=False), utc_now(), survey_flow["score"], rid))
        for ans in survey_flow["answers"]:
            db.execute("INSERT INTO survey_answers(response_id,question_id,answer_text,is_correct) VALUES(?,?,?,?)", (rid, ans["question_id"], ans["answer"], ans["correct"]))
        survey = db.fetchone("SELECT * FROM surveys WHERE id=?", (survey_flow["survey_id"],))
        if survey and int(survey["reward_points"] or 0) > 0:
            db.add_points(user.id, int(survey["reward_points"]), "survey_reward")
        context.user_data.pop("survey_flow", None)
        await message.reply_text((survey["end_text"] if survey else "") or "شكرًا لمشاركتك!", reply_markup=user_keyboard(db.list_buttons(None), is_admin(user.id, config, db), db)); return
    search_button = context.user_data.get("search_button")
    if search_button:
        term = message.text.strip(); rows = db.search(term, 15)
        kb = [[InlineKeyboardButton(f"{r['name']} · #{r['id']}", callback_data=f"open:{r['id']}")] for r in rows]
        context.user_data.pop("search_button", None)
        await message.reply_text(f"🔎 النتائج: {len(rows)}", reply_markup=InlineKeyboardMarkup(kb) if kb else None); return
    # ReplyKeyboard button names are resolved through database, not hardcoded handlers.
    row = db.fetchone("SELECT id FROM buttons WHERE name=? COLLATE NOCASE AND enabled=1 ORDER BY id DESC LIMIT 1", (message.text,))
    if not row:
        for candidate in db.fetchall("SELECT id,name FROM buttons WHERE enabled=1 ORDER BY id DESC"):
            icon = str(db.get_settings(int(candidate["id"])).get("icon", "")).strip()
            if icon and message.text == f"{icon} {candidate['name']}":
                row = candidate; break
    if row:
        await deliver_button(update, context, config, db, int(row["id"])); return
    # Exact keyword replies, then partial matching as a fallback.
    reply = db.fetchone("SELECT response FROM auto_replies WHERE enabled=1 AND keyword=? COLLATE NOCASE ORDER BY id DESC LIMIT 1", (message.text.strip(),))
    if not reply:
        reply = db.fetchone("SELECT response FROM auto_replies WHERE enabled=1 AND instr(lower(?),lower(keyword))>0 ORDER BY length(keyword) DESC LIMIT 1", (message.text.strip(),))
    if reply:
        await message.reply_text(reply["response"]); return
    if is_admin(user.id, config, db):
        from handlers.admin import _admin_home_text
        await message.reply_text(_admin_home_text(db), reply_markup=panel_keyboard(), parse_mode=ParseMode.MARKDOWN)


async def media_router(update: Update, context: ContextTypes.DEFAULT_TYPE, config: dict, db) -> None:
    message = update.effective_message
    user = update.effective_user
    if not message or not user:
        return
    if await message_wizard(update, context, config, db):
        return
    flow = context.user_data.get("info_flow")
    if flow:
        item = message_content(message)
        flow["answers"].append(item.get("text_value") or f"[{item['content_type']}: {item['file_id']}]")
        flow["index"] += 1
        if flow["index"] < len(flow["questions"]):
            await message.reply_text(flow["questions"][flow["index"]]); return
        db.execute("UPDATE information_requests SET answers_json=?,status='completed',updated_at=? WHERE id=?", (json.dumps(list(zip(flow['questions'], flow['answers'])), ensure_ascii=False), utc_now(), flow['request_id']))
        for owner_id in config.get("owner_ids", []):
            try: await context.bot.send_message(owner_id, f"طلب معلومات جديد من {user.full_name} ({user.id}).\n" + "\n".join(f"{q}: {a}" for q, a in zip(flow['questions'], flow['answers'])))
            except Exception: pass
        context.user_data.pop("info_flow", None); await message.reply_text("تم إرسال إجاباتك إلى الإدارة."); return
    # Media sent outside a wizard is ignored rather than stored accidentally.


async def document_router(update: Update, context: ContextTypes.DEFAULT_TYPE, config: dict, db) -> None:
    """Accept .mkfrky backups only from authorized admins."""
    message = update.effective_message
    user = update.effective_user
    if not message or not message.document or not user:
        return
    name = message.document.file_name or ""
    if not name.lower().endswith(".mkfrky"):
        await media_router(update, context, config, db)
        return
    if not is_admin(user.id, config, db):
        await message.reply_text("رفع النسخ الاحتياطية متاح للمشرفين فقط."); return
    file = await context.bot.get_file(message.document.file_id)
    target = __import__("pathlib").Path(config["database_path"]).parent / f"restore_{user.id}.mkfrky"
    await file.download_to_drive(custom_path=str(target))
    try:
        password = str(config.get("backup_password", ""))
        snapshot = read_backup(target, password)
        await message.reply_text("⚠️ سيتم استبدال بيانات البوت الحالية بالنسخة. أرسل /confirm_restore خلال 60 ثانية للتأكيد.")
        context.user_data["pending_restore"] = {"path": str(target), "snapshot": snapshot, "expires": datetime.now(timezone.utc).timestamp() + 60}
    except Exception as exc:
        await message.reply_text(f"تعذر قراءة النسخة: {exc}")
    finally:
        try: target.unlink(missing_ok=True)
        except Exception: pass


async def confirm_restore(update: Update, context: ContextTypes.DEFAULT_TYPE, config: dict, db) -> None:
    user = update.effective_user
    pending = context.user_data.get("pending_restore")
    if not user or not is_admin(user.id, config, db) or not pending:
        await update.effective_message.reply_text("لا توجد عملية استعادة معلقة."); return
    if datetime.now(timezone.utc).timestamp() > pending["expires"]:
        context.user_data.pop("pending_restore", None); await update.effective_message.reply_text("انتهت مهلة التأكيد. ارفع النسخة مرة أخرى."); return
    try:
        db.restore_snapshot(pending["snapshot"])
        db.log(user.id, "backup_restored", "restore confirmed")
        context.user_data.pop("pending_restore", None)
        await update.effective_message.reply_text("✅ تمت استعادة النسخة الاحتياطية.")
    except Exception as exc:
        await update.effective_message.reply_text(f"فشلت الاستعادة ولم تُعتمد العملية: {exc}")
