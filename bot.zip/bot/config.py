"""Configuration loading and validation for ARCEN Button Bot."""
from __future__ import annotations
import json
import logging
import os
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "config.json"

DEFAULTS: dict[str, Any] = {
    "bot_token": "PUT_BOT_TOKEN_HERE",
    "owner_ids": [],
    "admin_ids": [],
    "admin_contact_chat_id": None,
    "backup_channel_id": None,
    "timezone": "UTC",
    "database_path": "arcen.sqlite3",
    "backup_password": "",
    "daily_reward_points": 5,
    "welcome_text": "أهلًا بك في بوت آركين. اختر من القائمة بالأسفل.",
    "log_level": "INFO",
}


def load_config(path: str | Path = CONFIG_PATH) -> dict[str, Any]:
    """Load JSON settings, filling missing keys with safe defaults."""
    config_path = Path(path)
    if not config_path.exists():
        config_path.write_text(json.dumps(DEFAULTS, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        supplied = json.loads(config_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        raise RuntimeError(f"تعذر قراءة ملف الإعدادات {config_path}: {exc}") from exc
    if not isinstance(supplied, dict):
        raise RuntimeError("يجب أن يكون config.json كائن JSON.")
    config = {**DEFAULTS, **supplied}
    config["owner_ids"] = _integer_list(config.get("owner_ids"))
    config["admin_ids"] = _integer_list(config.get("admin_ids"))
    config["daily_reward_points"] = max(0, int(config.get("daily_reward_points", 5)))
    token = str(config.get("bot_token", "")).strip()
    if not token or token == "PUT_BOT_TOKEN_HERE":
        token_file = BASE_DIR / "token.txt"
        if token_file.exists():
            token = token_file.read_text(encoding="utf-8").strip()
    config["bot_token"] = token
    db_path = Path(str(config.get("database_path", "arcen.sqlite3")))
    config["database_path"] = str(db_path if db_path.is_absolute() else BASE_DIR / db_path)
    return config


def _integer_list(value: Any) -> list[int]:
    if not isinstance(value, (list, tuple, set)):
        return []
    result: list[int] = []
    for item in value:
        try:
            result.append(int(item))
        except (TypeError, ValueError):
            continue
    return sorted(set(result))


def setup_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        level=getattr(logging, str(level).upper(), logging.INFO),
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )
